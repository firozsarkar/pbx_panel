<?php
/**
 * ============================================================
 *  FreeSWITCH Extension Manager
 *  ফাইল রাখুন: /var/www/html/fs_manager.php
 *  লেখক: FreeSWITCH Admin Panel — Bangladesh Telecom Solution
 * ============================================================
 */

session_start();
error_reporting(0);
ini_set('display_errors', 0);

// ── কনফিগারেশন ──────────────────────────────────────────────
define('FS_HOST',     '127.0.0.1');
define('FS_PORT',     '8021');
define('FS_PASSWORD', 'ClueCon');
define('FS_DIR',      '/etc/freeswitch/directory/default');
define('ADMIN_PASS',  'admin123');   // ← পরিবর্তন করুন!
define('PAGE_TITLE',  'FreeSWITCH Manager');

// ── লগিন ────────────────────────────────────────────────────
if (isset($_POST['login_pass'])) {
    if ($_POST['login_pass'] === ADMIN_PASS) {
        $_SESSION['fs_auth'] = true;
    } else {
        $login_error = 'পাসওয়ার্ড ভুল!';
    }
}
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}
if (!isset($_SESSION['fs_auth'])) { show_login($login_error ?? ''); exit; }

// ── FreeSWITCH ESL Raw Socket ────────────────────────────────
function fs_connect() {
    $sock = @fsockopen(FS_HOST, intval(FS_PORT), $errno, $errstr, 5);
    if (!$sock) return false;
    stream_set_timeout($sock, 5);
    $buf = '';
    $t = time();
    while (!strstr($buf, 'auth/request') && (time()-$t)<5) {
        $buf .= fread($sock, 4096);
    }
    fwrite($sock, "auth " . FS_PASSWORD . "\r\n\r\n");
    $resp = ''; $t = time();
    while (!strstr($resp, 'Reply-Text') && (time()-$t)<5) {
        $resp .= fread($sock, 4096);
    }
    if (!strstr($resp, '+OK accepted')) { fclose($sock); return false; }
    return $sock;
}

function fs_api($sock, $cmd) {
    if (!$sock) return '';
    fwrite($sock, "api $cmd\r\n\r\n");
    $resp = ''; $t = time();
    while ((time()-$t)<8) {
        $chunk = fread($sock, 65536);
        if ($chunk === false || $chunk === '') break;
        $resp .= $chunk;
        if (preg_match('/Content-Length:\s*(\d+)/i', $resp, $m)) {
            $hdr_end = strpos($resp, "\n\n");
            if ($hdr_end !== false && strlen($resp) - $hdr_end - 2 >= intval($m[1])) break;
        }
    }
    $pos = strpos($resp, "\n\n");
    return $pos !== false ? trim(substr($resp, $pos + 2)) : trim($resp);
}

function fs_reload($sock) {
    return fs_api($sock, 'reloadxml');
}

// ── Extension XML তৈরি ──────────────────────────────────────
function ext_xml($number, $password, $name, $email, $context, $callgroup, $voicemail) {
    $vm = $voicemail ? 'true' : 'false';
    return '<?xml version="1.0" encoding="UTF-8"?>' . "\n" .
'<include>
  <user id="' . $number . '">
    <params>
      <param name="password" value="' . htmlspecialchars($password, ENT_XML1) . '"/>
      <param name="vm-password" value="' . htmlspecialchars($password, ENT_XML1) . '"/>
    </params>
    <variables>
      <variable name="toll_allow" value="domestic,international,local"/>
      <variable name="accountcode" value="' . $number . '"/>
      <variable name="user_context" value="' . htmlspecialchars($context, ENT_XML1) . '"/>
      <variable name="effective_caller_id_name" value="' . htmlspecialchars($name, ENT_XML1) . '"/>
      <variable name="effective_caller_id_number" value="' . $number . '"/>
      <variable name="outbound_caller_id_name" value="' . htmlspecialchars($name, ENT_XML1) . '"/>
      <variable name="outbound_caller_id_number" value="' . $number . '"/>
      <variable name="callgroup" value="' . htmlspecialchars($callgroup, ENT_XML1) . '"/>
      <variable name="vm-enabled" value="' . $vm . '"/>
      <variable name="vm-email-all-messages" value="true"/>
      <variable name="vm-mailto" value="' . htmlspecialchars($email, ENT_XML1) . '"/>
      <variable name="voicemail_enabled" value="' . $vm . '"/>
    </variables>
  </user>
</include>';
}

// ── Extension তালিকা পড়া ────────────────────────────────────
function get_extensions() {
    $dir = FS_DIR;
    $exts = [];
    if (!is_dir($dir)) return $exts;
    foreach (glob($dir . '/*.xml') as $file) {
        $xml = @simplexml_load_file($file);
        if (!$xml) continue;
        $user = $xml->user;
        if (!$user) continue;
        $id  = (string)$user['id'];
        $p   = [];
        if (isset($user->params->param)) {
            foreach ($user->params->param as $pm) $p[(string)$pm['name']] = (string)$pm['value'];
        }
        $v   = [];
        if (isset($user->variables->variable)) {
            foreach ($user->variables->variable as $vr) $v[(string)$vr['name']] = (string)$vr['value'];
        }
        $exts[] = [
            'number'    => $id,
            'password'  => $p['password'] ?? '',
            'name'      => $v['effective_caller_id_name'] ?? $id,
            'email'     => $v['vm-mailto'] ?? '',
            'context'   => $v['user_context'] ?? 'default',
            'callgroup' => $v['callgroup'] ?? '',
            'voicemail' => ($v['vm-enabled'] ?? 'false') === 'true',
            'file'      => basename($file),
        ];
    }
    usort($exts, function($a,$b){ return strcmp($a['number'],$b['number']); });
    return $exts;
}

// ── Sofia Status ─────────────────────────────────────────────
function get_sofia_status($sock) {
    $raw = fs_api($sock, 'sofia status');
    $profiles = [];
    if (empty($raw)) return $profiles;
    foreach (explode("\n", $raw) as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line,'===')!==false || strpos($line,'Name')===0 || strpos($line,'---')!==false) continue;
        $parts = preg_split('/\s+/', $line, -1, PREG_SPLIT_NO_EMPTY);
        if (count($parts) >= 2) {
            $profiles[] = ['name'=>$parts[0], 'type'=>$parts[1]??'', 'state'=>$parts[2]??'UNKNOWN'];
        }
    }
    return $profiles;
}

// ── Sofia Gateway Status ─────────────────────────────────────
function get_gateways($sock) {
    $raw = fs_api($sock, 'sofia status gateway');
    $gws = [];
    if (empty($raw)) return $gws;
    foreach (explode("\n", $raw) as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line,'===')!==false || strpos($line,'Name')===0) continue;
        $parts = preg_split('/\s+/', $line, -1, PREG_SPLIT_NO_EMPTY);
        if (count($parts) >= 3) {
            $gws[] = ['name'=>$parts[0], 'profile'=>$parts[1]??'', 'state'=>$parts[2]??'UNKNOWN', 'ping'=>$parts[3]??''];
        }
    }
    return $gws;
}

// ── Registrations ────────────────────────────────────────────
function get_registrations($sock) {
    $raw = fs_api($sock, 'show registrations as delim |');
    $regs = [];
    if (empty($raw)) return $regs;
    $lines = explode("\n", trim($raw));
    if (count($lines) < 2) return $regs;
    $header = explode('|', array_shift($lines));
    $header = array_map('trim', $header);
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line) || strpos($line,'total')!==false) continue;
        $cols = explode('|', $line);
        if (count($cols) >= count($header)) {
            $regs[] = array_combine($header, array_slice(array_map('trim',$cols), 0, count($header)));
        }
    }
    return $regs;
}

function get_active_calls($sock) {
    return fs_api($sock, 'show calls count');
}

function get_system_status($sock) {
    return fs_api($sock, 'status');
}

// ── AJAX হ্যান্ডলার ──────────────────────────────────────────
if (isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    $action = $_POST['action'];
    $result = ['ok'=>false, 'msg'=>''];

    if ($action === 'add' || $action === 'edit') {
        $num  = preg_replace('/[^0-9]/', '', $_POST['number'] ?? '');
        $pass = trim($_POST['password'] ?? '');
        $name = trim($_POST['name'] ?? '');
        $mail = trim($_POST['email'] ?? '');
        $ctx  = in_array($_POST['context']??'', ['default','public','internal']) ? $_POST['context'] : 'default';
        $cgrp = preg_replace('/[^a-z0-9_\- ]/i', '', $_POST['callgroup'] ?? '');
        $vm   = ($_POST['voicemail'] ?? 'false') === 'true';

        if (!preg_match('/^\d{3,6}$/', $num)) {
            echo json_encode(['ok'=>false,'msg'=>'ভুল এক্সটেনশন নম্বর (৩-৬ ডিজিট)']);
            exit;
        }
        if (strlen($pass) < 4) {
            echo json_encode(['ok'=>false,'msg'=>'পাসওয়ার্ড কমপক্ষে ৪ অক্ষর হতে হবে']);
            exit;
        }
        if (empty($name)) {
            echo json_encode(['ok'=>false,'msg'=>'নাম আবশ্যক']);
            exit;
        }

        if (!is_dir(FS_DIR)) {
            echo json_encode(['ok'=>false,'msg'=>'ডিরেক্টরি পাওয়া যায়নি: ' . FS_DIR]);
            exit;
        }

        $file = FS_DIR . '/' . $num . '.xml';
        if ($action === 'add' && file_exists($file)) {
            echo json_encode(['ok'=>false,'msg'=>"Extension $num ইতিমধ্যে বিদ্যমান!"]);
            exit;
        }

        $xml_content = ext_xml($num, $pass, $name, $mail, $ctx, $cgrp, $vm);
        if (file_put_contents($file, $xml_content) === false) {
            $result['msg'] = 'ফাইল লেখা সম্ভব হয়নি। Permission চেক করুন: chmod 775 ' . FS_DIR;
        } else {
            $sock = fs_connect();
            if ($sock) { fs_reload($sock); fclose($sock); }
            $result['ok']  = true;
            $result['msg'] = $action==='add' ? "✅ Extension $num সফলভাবে যোগ হয়েছে" : "✅ Extension $num আপডেট হয়েছে";
        }
    }

    elseif ($action === 'delete') {
        $num  = preg_replace('/[^0-9]/', '', $_POST['number'] ?? '');
        $file = FS_DIR . '/' . $num . '.xml';
        if (!file_exists($file)) {
            $result['msg'] = "ফাইল পাওয়া যায়নি: $num.xml";
        } else {
            unlink($file);
            $sock = fs_connect();
            if ($sock) { fs_reload($sock); fclose($sock); }
            $result['ok']  = true;
            $result['msg'] = "✅ Extension $num মুছে ফেলা হয়েছে";
        }
    }

    elseif ($action === 'reload') {
        $sock = fs_connect();
        if ($sock) {
            $r = fs_reload($sock);
            fclose($sock);
            $result['ok']  = true;
            $result['msg'] = '✅ FreeSWITCH XML পুনরায় লোড হয়েছে: ' . $r;
        } else {
            $result['msg'] = '❌ FreeSWITCH সংযোগ ব্যর্থ (Port ' . FS_PORT . ')';
        }
    }

    elseif ($action === 'status') {
        $sock = fs_connect();
        if ($sock) {
            $result['ok']     = true;
            $result['status'] = get_system_status($sock);
            $result['calls']  = get_active_calls($sock);
            $result['sofia']  = get_sofia_status($sock);
            $result['regs']   = get_registrations($sock);
            $result['gws']    = get_gateways($sock);
            fclose($sock);
        } else {
            $result['msg'] = '❌ FreeSWITCH ESL সংযোগ ব্যর্থ! পোর্ট ' . FS_PORT . ' চেক করুন।';
        }
    }

    echo json_encode($result);
    exit;
}

// ── ডেটা লোড ────────────────────────────────────────────────
$sock         = fs_connect();
$extensions   = get_extensions();
$sys_status   = $sock ? get_system_status($sock) : '';
$sofia_list   = $sock ? get_sofia_status($sock) : [];
$gateways     = $sock ? get_gateways($sock) : [];
$regs         = $sock ? get_registrations($sock) : [];
$active_calls = $sock ? get_active_calls($sock) : '0 total.';
if ($sock) fclose($sock);
$fs_connected = !empty($sys_status);
$reg_numbers  = array_column($regs, 'user');

// ── লগিন পেজ ─────────────────────────────────────────────────
function show_login($error = '') {
?><!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FreeSWITCH Manager — লগিন</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:'Segoe UI',sans-serif;background:linear-gradient(135deg,#0f2041 0%,#1a3a6e 50%,#0d1b3e 100%);min-height:100vh;display:flex;align-items:center;justify-content:center}
.login-wrap{text-align:center}
.logo{width:80px;height:80px;background:linear-gradient(135deg,#2563eb,#7c3aed);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:36px;box-shadow:0 12px 40px rgba(37,99,235,.5)}
.card{background:rgba(255,255,255,.05);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.1);border-radius:24px;padding:48px 40px;width:380px;box-shadow:0 25px 60px rgba(0,0,0,.5)}
h1{font-size:24px;color:#fff;margin-bottom:6px;font-weight:800}
p{color:#94a3b8;font-size:14px;margin-bottom:32px}
input{width:100%;padding:14px 18px;border:1.5px solid rgba(255,255,255,.15);border-radius:14px;font-size:15px;outline:none;transition:.2s;margin-bottom:14px;background:rgba(255,255,255,.08);color:#fff;font-family:inherit}
input::placeholder{color:#64748b}
input:focus{border-color:#2563eb;box-shadow:0 0 0 4px rgba(37,99,235,.2)}
button{width:100%;padding:15px;background:linear-gradient(135deg,#2563eb,#7c3aed);border:none;border-radius:14px;color:#fff;font-size:16px;font-weight:700;cursor:pointer;transition:.2s;font-family:inherit}
button:hover{transform:translateY(-2px);box-shadow:0 10px 30px rgba(37,99,235,.5)}
.err{background:rgba(220,38,38,.15);border:1px solid rgba(220,38,38,.3);color:#fca5a5;padding:12px 16px;border-radius:12px;font-size:13px;margin-bottom:16px}
.hint{color:#475569;font-size:12px;margin-top:16px}
</style>
</head>
<body>
<div class="login-wrap">
  <div class="card">
    <div class="logo">📞</div>
    <h1>FreeSWITCH Manager</h1>
    <p>Extension ব্যবস্থাপনা প্যানেল</p>
    <?php if($error): ?><div class="err">⚠️ <?= htmlspecialchars($error) ?></div><?php endif; ?>
    <form method="POST">
      <input type="password" name="login_pass" placeholder="🔒 অ্যাডমিন পাসওয়ার্ড" autofocus required>
      <button type="submit">প্রবেশ করুন →</button>
    </form>
    <p class="hint">ডিফল্ট পাসওয়ার্ড: admin123 (ADMIN_PASS পরিবর্তন করুন)</p>
  </div>
</div>
</body></html>
<?php
}
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FreeSWITCH Extension Manager</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>📞</text></svg>">
<style>
/* ────────────── Reset ────────────── */
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --primary:#2563eb;--secondary:#7c3aed;
  --success:#059669;--danger:#dc2626;--warning:#d97706;
  --bg:#0f172a;--surface:#1e293b;--surface2:#334155;
  --border:#334155;--text:#f1f5f9;--muted:#94a3b8;
  --sidebar:260px;
}
body{font-family:'Segoe UI',Tahoma,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex}

/* ────────────── Sidebar ────────────── */
.sidebar{width:var(--sidebar);background:linear-gradient(180deg,#0f172a 0%,#1a2744 100%);position:fixed;top:0;left:0;height:100vh;overflow-y:auto;z-index:100;display:flex;flex-direction:column;border-right:1px solid var(--border)}
.sidebar-logo{padding:22px 20px;border-bottom:1px solid var(--border)}
.sidebar-logo .brand{display:flex;align-items:center;gap:12px}
.brand-icon{width:44px;height:44px;background:linear-gradient(135deg,#2563eb,#7c3aed);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;box-shadow:0 4px 15px rgba(37,99,235,.4)}
.brand-text h2{color:#fff;font-size:16px;font-weight:800;line-height:1.2}
.brand-text p{color:var(--muted);font-size:11px}

.fs-conn{display:flex;align-items:center;gap:8px;padding:10px 20px;border-bottom:1px solid var(--border)}
.dot{width:8px;height:8px;border-radius:50%}
.dot.up{background:#10b981;box-shadow:0 0 8px #10b981;animation:blink 2s infinite}
.dot.down{background:#ef4444}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
.conn-label{font-size:12px;color:var(--muted)}
.conn-label strong{color:var(--text);font-size:11px}

nav{flex:1;padding:10px 12px;display:flex;flex-direction:column;gap:3px}
nav a{display:flex;align-items:center;gap:11px;padding:11px 14px;color:var(--muted);text-decoration:none;font-size:13px;font-weight:500;border-radius:12px;transition:.15s;cursor:pointer;border:none;background:none;width:100%;text-align:left}
nav a:hover,nav a.active{color:#fff;background:rgba(37,99,235,.15)}
nav a.active{border-left:3px solid var(--primary);padding-left:11px}
nav a .nbadge{margin-left:auto;background:rgba(37,99,235,.25);color:#60a5fa;font-size:10px;padding:2px 7px;border-radius:20px;font-weight:700}

.sidebar-info{padding:14px 16px;border-top:1px solid var(--border)}
.info-chip{background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:10px;padding:10px 12px;font-size:11px;color:var(--muted)}
.info-chip div{display:flex;justify-content:space-between;padding:3px 0}
.info-chip span{color:var(--text);font-family:monospace}
.sidebar-foot{padding:12px 16px;border-top:1px solid var(--border)}
.logout-btn{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:13px;text-decoration:none;transition:.15s;padding:8px 12px;border-radius:10px}
.logout-btn:hover{color:#fff;background:rgba(220,38,38,.15)}

/* ────────────── Main ────────────── */
.main{margin-left:var(--sidebar);flex:1;display:flex;flex-direction:column;min-height:100vh}

/* ────────────── Topbar ────────────── */
.topbar{background:rgba(30,41,59,.9);backdrop-filter:blur(10px);border-bottom:1px solid var(--border);height:62px;display:flex;align-items:center;justify-content:space-between;padding:0 24px;position:sticky;top:0;z-index:50}
.topbar-left{display:flex;align-items:center;gap:10px}
.topbar-left .breadcrumb{font-size:13px;color:var(--muted)}
.topbar-left .page-name{font-size:17px;font-weight:700;color:#fff}
.topbar-right{display:flex;align-items:center;gap:10px}
.btn{display:inline-flex;align-items:center;gap:7px;padding:9px 16px;border-radius:11px;font-size:13px;font-weight:600;cursor:pointer;border:none;transition:.2s;text-decoration:none;font-family:inherit}
.btn-primary{background:linear-gradient(135deg,var(--primary),var(--secondary));color:#fff;box-shadow:0 4px 14px rgba(37,99,235,.3)}
.btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(37,99,235,.4)}
.btn-ghost{background:rgba(255,255,255,.07);color:var(--text);border:1px solid var(--border)}
.btn-ghost:hover{background:rgba(255,255,255,.12)}
.btn-sm{padding:7px 13px;font-size:12px;border-radius:9px}
.btn-danger{background:rgba(220,38,38,.15);color:#f87171;border:1px solid rgba(220,38,38,.3)}
.btn-danger:hover{background:rgba(220,38,38,.25)}
.btn-edit{background:rgba(37,99,235,.12);color:#60a5fa;border:1px solid rgba(37,99,235,.25)}
.btn-edit:hover{background:rgba(37,99,235,.25)}
.spin{animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* ────────────── Content ────────────── */
.content{padding:22px 24px;flex:1}
.page{display:none}.page.active{display:block}

/* ────────────── Stats Grid ────────────── */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:22px}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:18px;display:flex;align-items:flex-start;gap:13px;transition:.2s}
.stat-card:hover{border-color:rgba(37,99,235,.4);transform:translateY(-1px)}
.stat-icon{width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.si-blue{background:rgba(37,99,235,.15);color:#60a5fa}
.si-green{background:rgba(5,150,105,.15);color:#34d399}
.si-red{background:rgba(220,38,38,.15);color:#f87171}
.si-purple{background:rgba(124,58,237,.15);color:#a78bfa}
.si-orange{background:rgba(234,88,12,.15);color:#fb923c}
.stat-label{font-size:11px;color:var(--muted);font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.stat-value{font-size:26px;font-weight:800;color:#fff;line-height:1.1;margin-top:3px}
.stat-sub{font-size:11px;color:var(--muted);margin-top:2px}

/* ────────────── Card ────────────── */
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;overflow:hidden;margin-bottom:18px}
.card-header{padding:15px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.02)}
.card-header h3{font-size:14px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px}
.card-body{padding:0}

/* ────────────── Search ────────────── */
.search-bar{padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.search-wrap{position:relative;flex:1;min-width:180px}
.search-wrap input{width:100%;padding:10px 14px 10px 36px;border:1.5px solid var(--border);border-radius:10px;font-size:13px;background:var(--bg);color:var(--text);outline:none;transition:.2s;font-family:inherit}
.search-wrap input:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(37,99,235,.15)}
.search-wrap svg{position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--muted)}
.filter-pill{display:flex;gap:6px}
.pill{padding:7px 14px;border-radius:20px;font-size:12px;font-weight:600;cursor:pointer;border:1.5px solid var(--border);background:transparent;color:var(--muted);transition:.15s;font-family:inherit}
.pill:hover{border-color:var(--primary);color:#60a5fa}
.pill.active{background:var(--primary);color:#fff;border-color:var(--primary)}

/* ────────────── Table ────────────── */
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:13px}
thead{background:rgba(0,0,0,.2)}
th{padding:11px 16px;text-align:left;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);border-bottom:1px solid var(--border);white-space:nowrap}
td{padding:13px 16px;border-bottom:1px solid rgba(51,65,85,.5);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.ext-num{font-weight:800;font-size:15px;color:#60a5fa;font-family:monospace}
.ext-name{font-weight:600;color:#fff}
.ext-sub{font-size:11px;color:var(--muted);margin-top:2px}

/* ────────────── Badges ────────────── */
.badge{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;white-space:nowrap}
.badge-green{background:rgba(5,150,105,.15);color:#34d399;border:1px solid rgba(5,150,105,.3)}
.badge-red{background:rgba(220,38,38,.15);color:#f87171;border:1px solid rgba(220,38,38,.3)}
.badge-blue{background:rgba(37,99,235,.15);color:#60a5fa;border:1px solid rgba(37,99,235,.3)}
.badge-purple{background:rgba(124,58,237,.15);color:#a78bfa;border:1px solid rgba(124,58,237,.3)}
.badge-gray{background:rgba(100,116,139,.15);color:#94a3b8;border:1px solid rgba(100,116,139,.3)}
.badge-orange{background:rgba(234,88,12,.15);color:#fb923c;border:1px solid rgba(234,88,12,.3)}
.act-btns{display:flex;gap:7px;white-space:nowrap}

/* ────────────── Modal ────────────── */
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.65);backdrop-filter:blur(6px);z-index:200;align-items:center;justify-content:center;padding:16px}
.overlay.open{display:flex}
.modal{background:var(--surface);border:1px solid var(--border);border-radius:24px;width:100%;max-width:560px;max-height:92vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 30px 80px rgba(0,0,0,.6)}
.modal-head{background:linear-gradient(135deg,var(--primary),var(--secondary));padding:18px 22px;display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.modal-head h2{color:#fff;font-size:16px;font-weight:700;display:flex;align-items:center;gap:10px}
.modal-close{background:rgba(255,255,255,.15);border:none;color:#fff;cursor:pointer;padding:7px;border-radius:10px;display:flex;align-items:center;transition:.2s;line-height:0}
.modal-close:hover{background:rgba(255,255,255,.25)}
.modal-body{overflow-y:auto;padding:22px;flex:1}
.form-group{margin-bottom:16px}
label{display:block;font-size:12px;font-weight:700;color:var(--muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em}
.req{color:var(--danger)}
.input-wrap{position:relative}
.input-wrap svg{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--muted);pointer-events:none}
.form-control{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:11px;font-size:14px;outline:none;background:var(--bg);color:var(--text);transition:.2s;font-family:inherit}
.form-control:focus{border-color:var(--primary);box-shadow:0 0 0 3px rgba(37,99,235,.15)}
.has-icon{padding-left:36px}
.has-icon-right{padding-right:38px}
.form-control.error{border-color:var(--danger)}
.err-msg{color:#f87171;font-size:11px;margin-top:4px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.pass-btn{position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;color:var(--muted);padding:4px;border-radius:6px}
.pass-btn:hover{color:var(--text)}
.toggle-field{display:flex;align-items:center;justify-content:space-between;background:var(--bg);border:1.5px solid var(--border);border-radius:11px;padding:12px 14px}
.toggle-field-text p{font-size:13px;font-weight:600;color:var(--text)}
.toggle-field-text small{font-size:11px;color:var(--muted)}
.toggle{position:relative;width:44px;height:24px;flex-shrink:0}
.toggle input{opacity:0;width:0;height:0;position:absolute}
.slider{position:absolute;inset:0;background:#334155;border-radius:24px;cursor:pointer;transition:.2s}
.slider::before{content:'';position:absolute;width:18px;height:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.2s;box-shadow:0 2px 4px rgba(0,0,0,.3)}
input:checked+.slider{background:var(--primary)}
input:checked+.slider::before{transform:translateX(20px)}
.xml-box{background:#050d1f;border:1px solid rgba(37,99,235,.2);border-radius:12px;padding:14px;margin-top:8px}
.xml-label{color:#3b82f6;font-size:11px;font-family:monospace;margin-bottom:8px;display:flex;align-items:center;gap:6px}
.xml-box pre{font-size:11px;color:#a5b4fc;font-family:'Courier New',monospace;line-height:1.6;overflow-x:auto;white-space:pre-wrap;word-break:break-all}
.modal-footer{padding:14px 22px;border-top:1px solid var(--border);display:flex;gap:10px;flex-shrink:0;background:rgba(0,0,0,.2)}

/* ────────────── Console ────────────── */
pre.console{background:#050d1f;color:#94a3b8;border-radius:12px;padding:16px;font-size:12px;font-family:'Courier New',monospace;overflow-x:auto;line-height:1.7;white-space:pre-wrap;word-break:break-all;border:1px solid rgba(37,99,235,.15)}

/* ────────────── Empty State ────────────── */
.empty-state{text-align:center;padding:52px;color:var(--muted)}
.empty-state .em-icon{font-size:48px;margin-bottom:14px;opacity:.4}
.empty-state p{font-size:15px;font-weight:600;color:var(--text);margin-bottom:6px}
.empty-state small{font-size:13px}

/* ────────────── Status Grid ────────────── */
.status-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:18px}
.s-card{background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:18px}
.s-card h4{font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;margin-bottom:12px}
.info-row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid rgba(51,65,85,.5);font-size:13px}
.info-row:last-child{border-bottom:none}
.info-row span:first-child{color:var(--muted)}
.info-row .v{font-weight:600;color:var(--text);text-align:right;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ────────────── Toast ────────────── */
.toast{position:fixed;top:18px;right:18px;z-index:999;display:flex;align-items:center;gap:10px;padding:14px 18px;border-radius:14px;font-size:14px;font-weight:600;box-shadow:0 10px 30px rgba(0,0,0,.4);transform:translateX(130%);transition:.3s cubic-bezier(.34,1.56,.64,1);max-width:340px}
.toast.show{transform:translateX(0)}
.toast.success{background:#065f46;color:#a7f3d0;border:1px solid rgba(16,185,129,.3)}
.toast.error{background:#7f1d1d;color:#fca5a5;border:1px solid rgba(220,38,38,.3)}

/* ────────────── Trunk Row ────────────── */
.trunk-dot{width:9px;height:9px;border-radius:50%;display:inline-block;margin-right:7px}
.trunk-dot.up{background:#10b981;box-shadow:0 0 6px #10b981}
.trunk-dot.down{background:#ef4444}

/* ────────────── Footer ────────────── */
.table-foot{padding:10px 18px;border-top:1px solid var(--border);color:var(--muted);font-size:12px}

@media(max-width:768px){
  .sidebar{display:none}
  .main{margin-left:0}
  .status-grid{grid-template-columns:1fr}
  .form-row{grid-template-columns:1fr}
}
</style>
</head>
<body>

<!-- ══════════════ SIDEBAR ══════════════ -->
<div class="sidebar">
  <div class="sidebar-logo">
    <div class="brand">
      <div class="brand-icon">📞</div>
      <div class="brand-text">
        <h2>FreeSWITCH</h2>
        <p>Extension Manager</p>
      </div>
    </div>
  </div>
  <div class="fs-conn">
    <div class="dot <?= $fs_connected ? 'up' : 'down' ?>"></div>
    <div class="conn-label">
      <strong>ESL <?= $fs_connected ? 'সংযুক্ত' : 'বিচ্ছিন্ন' ?></strong><br>
      <?= FS_HOST ?>:<?= FS_PORT ?>
    </div>
  </div>
  <nav>
    <a onclick="showPage('dashboard')" id="nav-dashboard" class="active">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
      ড্যাশবোর্ড
    </a>
    <a onclick="showPage('extensions')" id="nav-extensions">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
      Extension তালিকা
      <span class="nbadge"><?= count($extensions) ?></span>
    </a>
    <a onclick="showPage('trunks')" id="nav-trunks">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
      Trunk / Gateway
      <span class="nbadge"><?= count($sofia_list) + count($gateways) ?></span>
    </a>
    <a onclick="showPage('regs')" id="nav-regs">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      SIP রেজিস্ট্রেশন
      <span class="nbadge"><?= count($regs) ?></span>
    </a>
    <a onclick="showPage('status')" id="nav-status">
      <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
      সিস্টেম স্ট্যাটাস
    </a>
  </nav>
  <div class="sidebar-info">
    <div class="info-chip">
      <div><span style="color:var(--muted)">Directory</span><span>/etc/freeswitch/dir...</span></div>
      <div><span style="color:var(--muted)">Extensions</span><span><?= count($extensions) ?> টি</span></div>
      <div><span style="color:var(--muted)">Registered</span><span style="color:#34d399"><?= count($regs) ?> টি</span></div>
    </div>
  </div>
  <div class="sidebar-foot">
    <a href="?logout=1" class="logout-btn">
      <svg width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      লগ আউট
    </a>
  </div>
</div>

<!-- ══════════════ MAIN ══════════════ -->
<div class="main">
  <!-- Topbar -->
  <div class="topbar">
    <div class="topbar-left">
      <span class="breadcrumb">FreeSWITCH /</span>
      <span class="page-name" id="page-name">ড্যাশবোর্ড</span>
    </div>
    <div class="topbar-right">
      <button class="btn btn-ghost btn-sm" onclick="reloadFS(this)">
        <svg id="reload-svg" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
        XML Reload
      </button>
      <button class="btn btn-primary btn-sm" onclick="openAddModal()">
        <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        নতুন Extension
      </button>
    </div>
  </div>

  <div class="content">

    <!-- ─────────── PAGE: Dashboard ─────────── -->
    <div class="page active" id="page-dashboard">
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon si-blue">👥</div>
          <div>
            <div class="stat-label">মোট Extension</div>
            <div class="stat-value"><?= count($extensions) ?></div>
            <div class="stat-sub">XML ফাইল</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-green">✅</div>
          <div>
            <div class="stat-label">রেজিস্টার্ড</div>
            <div class="stat-value"><?= count($regs) ?></div>
            <div class="stat-sub">সক্রিয় SIP</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-purple">🌐</div>
          <div>
            <div class="stat-label">Sofia Profile</div>
            <div class="stat-value"><?= count($sofia_list) ?></div>
            <div class="stat-sub">Trunk/Profile</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-orange">📞</div>
          <div>
            <div class="stat-label">সক্রিয় কল</div>
            <div class="stat-value" id="calls-val"><?php preg_match('/(\d+)\s+total/', $active_calls, $cm); echo $cm[1]??0; ?></div>
            <div class="stat-sub">বর্তমান</div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-red">🚫</div>
          <div>
            <div class="stat-label">আনরেজিস্টার্ড</div>
            <div class="stat-value"><?= count($extensions) - count($regs) ?></div>
            <div class="stat-sub">অফলাইন</div>
          </div>
        </div>
      </div>

      <?php if ($fs_connected): ?>
      <div class="card">
        <div class="card-header">
          <h3>🖥️ FreeSWITCH Status</h3>
          <span class="badge badge-green">● সংযুক্ত</span>
        </div>
        <div class="card-body" style="padding:16px"><pre class="console"><?= htmlspecialchars($sys_status) ?></pre></div>
      </div>
      <?php else: ?>
      <div class="card">
        <div class="card-header"><h3>⚠️ সংযোগ সমস্যা</h3><span class="badge badge-red">বিচ্ছিন্ন</span></div>
        <div class="card-body" style="padding:24px">
          <div class="empty-state">
            <div class="em-icon">🔌</div>
            <p>FreeSWITCH ESL সংযোগ করা যাচ্ছে না</p>
            <small>নিশ্চিত করুন: mod_event_socket চালু আছে এবং পোর্ট <?= FS_PORT ?> খোলা আছে</small>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <div class="card">
        <div class="card-header"><h3>📋 সাম্প্রতিক Extension</h3><button class="btn btn-ghost btn-sm" onclick="showPage('extensions')">সব দেখুন →</button></div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Ext #</th><th>নাম</th><th>Context</th><th>Voicemail</th><th>স্ট্যাটাস</th></tr></thead>
            <tbody>
            <?php foreach (array_slice($extensions, 0, 6) as $e):
              $is_reg = in_array($e['number'], $reg_numbers);
            ?>
            <tr>
              <td><span class="ext-num"><?= htmlspecialchars($e['number']) ?></span></td>
              <td><div class="ext-name"><?= htmlspecialchars($e['name']) ?></div><div class="ext-sub"><?= htmlspecialchars($e['email']?:'—') ?></div></td>
              <td><span class="badge badge-blue"><?= htmlspecialchars($e['context']) ?></span></td>
              <td><span class="badge <?= $e['voicemail'] ? 'badge-green' : 'badge-gray' ?>"><?= $e['voicemail'] ? 'সক্রিয়' : 'বন্ধ' ?></span></td>
              <td><span class="badge <?= $is_reg ? 'badge-green' : 'badge-red' ?>"><?= $is_reg ? '● Registered' : '○ Unregistered' ?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- ─────────── PAGE: Extensions ─────────── -->
    <div class="page" id="page-extensions">
      <div class="card">
        <div class="card-header">
          <h3>👥 Extension তালিকা</h3>
          <button class="btn btn-primary btn-sm" onclick="openAddModal()">+ নতুন Extension যোগ</button>
        </div>
        <div class="search-bar">
          <div class="search-wrap">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="text" id="ext-search" placeholder="নম্বর বা নাম দিয়ে খুঁজুন..." oninput="filterExts()">
          </div>
          <div class="filter-pill">
            <button class="pill active" onclick="setF('all',this)">সব</button>
            <button class="pill" onclick="setF('registered',this)">রেজিস্টার্ড</button>
            <button class="pill" onclick="setF('unregistered',this)">আনরেজিস্টার্ড</button>
          </div>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Ext #</th>
                <th>নাম / ইমেইল</th>
                <th>পাসওয়ার্ড</th>
                <th>Context</th>
                <th>Call Group</th>
                <th>Voicemail</th>
                <th>স্ট্যাটাস</th>
                <th>কার্যক্রম</th>
              </tr>
            </thead>
            <tbody id="ext-tbody">
            <?php foreach ($extensions as $e):
              $is_reg = in_array($e['number'], $reg_numbers);
            ?>
            <tr data-n="<?= $e['number'] ?>" data-nm="<?= strtolower($e['name']) ?>" data-s="<?= $is_reg ? 'registered' : 'unregistered' ?>">
              <td><span class="ext-num"><?= htmlspecialchars($e['number']) ?></span></td>
              <td>
                <div class="ext-name"><?= htmlspecialchars($e['name']) ?></div>
                <div class="ext-sub"><?= htmlspecialchars($e['email']?:'—') ?></div>
              </td>
              <td><span style="font-family:monospace;font-size:12px;color:var(--muted)">••••••••</span></td>
              <td><span class="badge badge-blue"><?= htmlspecialchars($e['context']) ?></span></td>
              <td><span style="color:var(--muted);font-size:12px"><?= htmlspecialchars($e['callgroup']?:'—') ?></span></td>
              <td><span class="badge <?= $e['voicemail'] ? 'badge-green' : 'badge-gray' ?>"><?= $e['voicemail'] ? '✓ সক্রিয়' : '✗ বন্ধ' ?></span></td>
              <td>
                <span class="badge <?= $is_reg ? 'badge-green' : 'badge-red' ?>">
                  <span class="trunk-dot <?= $is_reg ? 'up' : 'down' ?>" style="width:6px;height:6px;margin-right:4px"></span>
                  <?= $is_reg ? 'Registered' : 'Unregistered' ?>
                </span>
              </td>
              <td>
                <div class="act-btns">
                  <button class="btn btn-edit btn-sm" onclick='openEditModal(<?= json_encode($e) ?>)'>
                    ✏️ সম্পাদনা
                  </button>
                  <button class="btn btn-danger btn-sm" onclick="confirmDelete('<?= $e['number'] ?>','<?= addslashes($e['name']) ?>')">
                    🗑️ মুছুন
                  </button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($extensions)): ?>
            <tr><td colspan="8">
              <div class="empty-state">
                <div class="em-icon">📂</div>
                <p>কোনো Extension পাওয়া যায়নি</p>
                <small><?= FS_DIR ?> ফোল্ডারে কোনো XML ফাইল নেই</small>
              </div>
            </td></tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
        <div class="table-foot">মোট <strong><?= count($extensions) ?></strong> Extension — <?= FS_DIR ?></div>
      </div>
    </div>

    <!-- ─────────── PAGE: Trunks ─────────── -->
    <div class="page" id="page-trunks">
      <div class="stats-grid" style="margin-bottom:18px">
        <div class="stat-card">
          <div class="stat-icon si-green">🔗</div>
          <div>
            <div class="stat-label">Sofia Profile</div>
            <div class="stat-value"><?= count($sofia_list) ?></div>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon si-purple">🌐</div>
          <div>
            <div class="stat-label">Gateway</div>
            <div class="stat-value"><?= count($gateways) ?></div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-header"><h3>🔗 Sofia Profile স্ট্যাটাস</h3><span class="badge badge-blue">sofia status</span></div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Profile নাম</th><th>ধরন</th><th>স্ট্যাটাস</th></tr></thead>
            <tbody>
            <?php if (!empty($sofia_list)): foreach ($sofia_list as $t): ?>
            <tr>
              <td><strong style="color:#fff;font-family:monospace"><?= htmlspecialchars($t['name']) ?></strong></td>
              <td><span class="badge badge-purple"><?= htmlspecialchars($t['type']) ?></span></td>
              <td>
                <span class="badge <?= stripos($t['state'],'RUN')!==false ? 'badge-green' : 'badge-red' ?>">
                  <span class="trunk-dot <?= stripos($t['state'],'RUN')!==false ? 'up' : 'down' ?>" style="width:6px;height:6px;margin-right:4px"></span>
                  <?= htmlspecialchars($t['state']) ?>
                </span>
              </td>
            </tr>
            <?php endforeach; else: ?>
            <tr><td colspan="3"><div class="empty-state"><div class="em-icon">⚡</div><p>Sofia Profile তথ্য নেই</p><small>FreeSWITCH সংযুক্ত নয়</small></div></td></tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <?php if (!empty($gateways)): ?>
      <div class="card">
        <div class="card-header"><h3>🌐 Gateway স্ট্যাটাস</h3><span class="badge badge-blue">sofia status gateway</span></div>
        <div class="table-wrap">
          <table>
            <thead><tr><th>Gateway নাম</th><th>Profile</th><th>Ping</th><th>স্ট্যাটাস</th></tr></thead>
            <tbody>
            <?php foreach ($gateways as $g): ?>
            <tr>
              <td><strong style="color:#fff;font-family:monospace"><?= htmlspecialchars($g['name']) ?></strong></td>
              <td><span class="badge badge-blue"><?= htmlspecialchars($g['profile']) ?></span></td>
              <td><span style="color:var(--muted);font-size:12px"><?= htmlspecialchars($g['ping']) ?></span></td>
              <td>
                <span class="badge <?= stripos($g['state'],'UP')!==false || stripos($g['state'],'NOREG')!==false ? 'badge-green' : 'badge-red' ?>">
                  <?= htmlspecialchars($g['state']) ?>
                </span>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>

      <?php if ($fs_connected): ?>
      <div class="card">
        <div class="card-header"><h3>📟 Raw Sofia Status</h3></div>
        <div style="padding:16px"><pre class="console"><?php
          $s2 = fs_connect();
          if($s2){echo htmlspecialchars(fs_api($s2,'sofia status'));fclose($s2);}
        ?></pre></div>
      </div>
      <?php endif; ?>
    </div>

    <!-- ─────────── PAGE: Registrations ─────────── -->
    <div class="page" id="page-regs">
      <div class="card">
        <div class="card-header">
          <h3>🔐 সক্রিয় SIP রেজিস্ট্রেশন</h3>
          <span class="badge badge-green"><?= count($regs) ?> সক্রিয়</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <?php if (!empty($regs)): foreach (array_keys($regs[0]) as $col): ?>
                <th><?= htmlspecialchars($col) ?></th>
                <?php endforeach; endif; ?>
              </tr>
            </thead>
            <tbody>
            <?php if (!empty($regs)): foreach ($regs as $r): ?>
            <tr><?php foreach ($r as $v): ?>
              <td style="font-size:12px;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?= htmlspecialchars($v) ?>"><?= htmlspecialchars($v?:'—') ?></td>
            <?php endforeach; ?></tr>
            <?php endforeach; else: ?>
            <tr><td colspan="10">
              <div class="empty-state">
                <div class="em-icon">📵</div>
                <p>কোনো সক্রিয় রেজিস্ট্রেশন নেই</p>
                <small>কোনো SIP ফোন/সফটফোন সংযুক্ত নয়</small>
              </div>
            </td></tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php if ($fs_connected): ?>
      <div class="card">
        <div class="card-header"><h3>📟 Raw Registrations Output</h3></div>
        <div style="padding:16px"><pre class="console"><?php
          $s3 = fs_connect();
          if($s3){echo htmlspecialchars(fs_api($s3,'show registrations'));fclose($s3);}
          else echo 'FreeSWITCH সংযোগ নেই';
        ?></pre></div>
      </div>
      <?php endif; ?>
    </div>

    <!-- ─────────── PAGE: Status ─────────── -->
    <div class="page" id="page-status">
      <div class="status-grid">
        <div class="s-card">
          <h4>🖥️ সিস্টেম তথ্য</h4>
          <div class="info-row"><span>ESL Host</span><span class="v"><?= FS_HOST ?>:<?= FS_PORT ?></span></div>
          <div class="info-row"><span>সংযোগ</span><span class="v" style="color:<?= $fs_connected ? '#34d399' : '#f87171' ?>"><?= $fs_connected ? '✓ সংযুক্ত' : '✗ বিচ্ছিন্ন' ?></span></div>
          <div class="info-row"><span>Directory</span><span class="v" style="font-size:11px;font-family:monospace"><?= FS_DIR ?></span></div>
          <div class="info-row"><span>মোট Extension</span><span class="v"><?= count($extensions) ?></span></div>
          <div class="info-row"><span>Registered</span><span class="v" style="color:#34d399"><?= count($regs) ?></span></div>
          <div class="info-row"><span>PHP ভার্সন</span><span class="v"><?= PHP_VERSION ?></span></div>
          <div class="info-row"><span>সার্ভার সময়</span><span class="v"><?= date('d/m/Y H:i:s') ?></span></div>
        </div>
        <div class="s-card">
          <h4>📞 কল তথ্য</h4>
          <div class="info-row"><span>সক্রিয় কল</span><span class="v"><?= htmlspecialchars($active_calls) ?></span></div>
          <div class="info-row"><span>Sofia Profile</span><span class="v"><?= count($sofia_list) ?> টি</span></div>
          <div class="info-row"><span>Gateway</span><span class="v"><?= count($gateways) ?> টি</span></div>
          <div class="info-row"><span>mod_event_socket</span><span class="v" style="color:<?= $fs_connected ? '#34d399' : '#f87171' ?>"><?= $fs_connected ? '✓ লোড' : '✗ লোড নেই' ?></span></div>
        </div>
      </div>
      <div class="card">
        <div class="card-header"><h3>📟 FreeSWITCH Console Output</h3><span style="font-size:12px;color:var(--muted);font-family:monospace">fs_cli -x "status"</span></div>
        <div style="padding:16px">
          <pre class="console"><?= $sys_status ? htmlspecialchars($sys_status) : '❌ FreeSWITCH সংযোগ নেই। mod_event_socket চালু করুন।' ?></pre>
        </div>
      </div>
    </div>

  </div><!-- /content -->
</div><!-- /main -->

<!-- ══════════════ MODALS ══════════════ -->
<!-- Add / Edit -->
<div class="overlay" id="ext-modal">
  <div class="modal">
    <div class="modal-head">
      <h2>📞 <span id="modal-title">নতুন Extension যোগ</span></h2>
      <button class="modal-close" onclick="closeModal()">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <input type="hidden" id="form-action" value="add">
      <div class="form-row">
        <div class="form-group">
          <label>Extension নম্বর <span class="req">*</span></label>
          <div class="input-wrap">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.6 2.18h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
            <input type="text" id="f-number" class="form-control has-icon" placeholder="যেমন: 1001" maxlength="6" oninput="updatePreview()">
          </div>
          <div class="err-msg" id="err-number"></div>
        </div>
        <div class="form-group">
          <label>SIP পাসওয়ার্ড <span class="req">*</span></label>
          <div class="input-wrap">
            <input type="password" id="f-password" class="form-control has-icon-right" placeholder="শক্তিশালী পাসওয়ার্ড">
            <button type="button" class="pass-btn" onclick="togglePass()">👁️</button>
          </div>
          <div class="err-msg" id="err-password"></div>
        </div>
      </div>
      <div class="form-group">
        <label>প্রদর্শন নাম <span class="req">*</span></label>
        <input type="text" id="f-name" class="form-control" placeholder="যেমন: Alice Rahman" oninput="updatePreview()">
        <div class="err-msg" id="err-name"></div>
      </div>
      <div class="form-group">
        <label>ইমেইল ঠিকানা <span style="font-weight:400;color:var(--muted)">(Voicemail notification)</span></label>
        <input type="email" id="f-email" class="form-control" placeholder="user@example.com">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Context</label>
          <select id="f-context" class="form-control" onchange="updatePreview()">
            <option value="default">default</option>
            <option value="public">public</option>
            <option value="internal">internal</option>
          </select>
        </div>
        <div class="form-group">
          <label>Call Group</label>
          <input type="text" id="f-callgroup" class="form-control" placeholder="sales, support...">
        </div>
      </div>
      <div class="form-group">
        <div class="toggle-field">
          <div class="toggle-field-text">
            <p>Voicemail সক্রিয় করুন</p>
            <small>মিসড কল ভয়েস বার্তা সংরক্ষণ হবে</small>
          </div>
          <label class="toggle">
            <input type="checkbox" id="f-voicemail" checked onchange="updatePreview()">
            <span class="slider"></span>
          </label>
        </div>
      </div>
      <div class="xml-box">
        <div class="xml-label">🖥️ XML Preview — <span id="xml-path">/etc/freeswitch/directory/default/XXXX.xml</span></div>
        <pre id="xml-prev"></pre>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" style="flex:1" onclick="closeModal()">বাতিল</button>
      <button class="btn btn-primary" style="flex:2" id="submit-btn" onclick="submitExt()">
        💾 <span id="submit-txt">সংরক্ষণ করুন</span>
      </button>
    </div>
  </div>
</div>

<!-- Delete Confirm -->
<div class="overlay" id="del-modal">
  <div class="modal" style="max-width:380px">
    <div class="modal-head" style="background:linear-gradient(135deg,#dc2626,#b91c1c)">
      <h2>🗑️ Extension মুছুন</h2>
      <button class="modal-close" onclick="closeDelModal()">
        <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    </div>
    <div class="modal-body" style="text-align:center;padding:30px 24px">
      <div style="font-size:56px;margin-bottom:14px">⚠️</div>
      <p style="font-size:16px;font-weight:700;color:#fff;margin-bottom:8px">নিশ্চিত করুন</p>
      <p style="color:var(--muted);font-size:14px;margin-bottom:4px">Extension <strong id="del-num" style="color:#60a5fa;font-family:monospace"></strong></p>
      <p style="color:var(--muted);font-size:14px;margin-bottom:14px">(<span id="del-name"></span>) মুছে ফেলবেন?</p>
      <div style="background:rgba(220,38,38,.1);border:1px solid rgba(220,38,38,.2);border-radius:10px;padding:10px;font-size:12px;color:#f87171">
        XML ফাইলটি স্থায়ীভাবে মুছে যাবে এবং FreeSWITCH reloadxml হবে
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" style="flex:1" onclick="closeDelModal()">বাতিল</button>
      <button class="btn" style="flex:1;background:#dc2626;color:#fff;border:none" onclick="doDelete()">✓ হ্যাঁ, মুছুন</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="toast" id="toast"></div>

<!-- ══════════════ JS ══════════════ -->
<script>
// ── Page Nav ─────────────────────────────────────
const PAGES = ['dashboard','extensions','trunks','regs','status'];
const NAMES = {dashboard:'ড্যাশবোর্ড',extensions:'Extension তালিকা',trunks:'Trunk / Gateway',regs:'SIP রেজিস্ট্রেশন',status:'সিস্টেম স্ট্যাটাস'};
function showPage(p) {
  PAGES.forEach(x => {
    document.getElementById('page-'+x).classList.toggle('active', x===p);
    const n = document.getElementById('nav-'+x);
    if(n) n.classList.toggle('active', x===p);
  });
  document.getElementById('page-name').textContent = NAMES[p]||p;
}

// ── Toast ─────────────────────────────────────────
function showToast(msg, type='success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast '+type+' show';
  setTimeout(()=>t.classList.remove('show'), 3800);
}

// ── Reload XML ────────────────────────────────────
function reloadFS(btn) {
  const svg = document.getElementById('reload-svg');
  svg.classList.add('spin');
  post({action:'reload'}).then(d=>{
    showToast(d.msg, d.ok?'success':'error');
  }).catch(()=>showToast('রিলোড ব্যর্থ!','error'))
  .finally(()=>svg.classList.remove('spin'));
}

// ── AJAX helper ───────────────────────────────────
function post(data) {
  const body = Object.entries(data).map(([k,v])=>encodeURIComponent(k)+'='+encodeURIComponent(v)).join('&');
  return fetch('', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body}).then(r=>r.json());
}

// ── Modal ─────────────────────────────────────────
function openAddModal() {
  document.getElementById('modal-title').textContent = 'নতুন Extension যোগ';
  document.getElementById('submit-txt').textContent = 'সংরক্ষণ করুন';
  document.getElementById('form-action').value = 'add';
  ['number','password','name','email'].forEach(f=>{ document.getElementById('f-'+f).value=''; });
  document.getElementById('f-context').value = 'default';
  document.getElementById('f-callgroup').value = '';
  document.getElementById('f-voicemail').checked = true;
  document.getElementById('f-number').readOnly = false;
  clearErr();
  updatePreview();
  document.getElementById('ext-modal').classList.add('open');
}

function openEditModal(ext) {
  document.getElementById('modal-title').textContent = 'Extension সম্পাদনা — '+ext.number;
  document.getElementById('submit-txt').textContent = 'আপডেট করুন';
  document.getElementById('form-action').value = 'edit';
  document.getElementById('f-number').value = ext.number;
  document.getElementById('f-number').readOnly = true;
  document.getElementById('f-password').value = ext.password;
  document.getElementById('f-name').value = ext.name;
  document.getElementById('f-email').value = ext.email;
  document.getElementById('f-context').value = ext.context;
  document.getElementById('f-callgroup').value = ext.callgroup;
  document.getElementById('f-voicemail').checked = ext.voicemail;
  clearErr();
  updatePreview();
  document.getElementById('ext-modal').classList.add('open');
}

function closeModal() {
  document.getElementById('ext-modal').classList.remove('open');
  document.getElementById('f-number').readOnly = false;
}

function clearErr() {
  ['number','password','name'].forEach(f=>{
    document.getElementById('err-'+f).textContent='';
    document.getElementById('f-'+f).classList.remove('error');
  });
}

function togglePass() {
  const i = document.getElementById('f-password');
  i.type = i.type==='password' ? 'text' : 'password';
}

// ── XML Preview ───────────────────────────────────
function updatePreview() {
  const num = document.getElementById('f-number').value||'XXXX';
  const name = document.getElementById('f-name').value||'User Name';
  const ctx = document.getElementById('f-context').value;
  const cg = document.getElementById('f-callgroup').value||'default';
  const vm = document.getElementById('f-voicemail').checked;
  document.getElementById('xml-path').textContent = '/etc/freeswitch/directory/default/'+num+'.xml';
  document.getElementById('xml-prev').textContent =
`<?xml version="1.0" encoding="UTF-8"?>
<include>
  <user id="${num}">
    <params>
      <param name="password" value="●●●●●●"/>
      <param name="vm-password" value="●●●●●●"/>
    </params>
    <variables>
      <variable name="accountcode" value="${num}"/>
      <variable name="user_context" value="${ctx}"/>
      <variable name="effective_caller_id_name" value="${name}"/>
      <variable name="effective_caller_id_number" value="${num}"/>
      <variable name="callgroup" value="${cg}"/>
      <variable name="vm-enabled" value="${vm?'true':'false'}"/>
    </variables>
  </user>
</include>`;
}
updatePreview();

// ── Submit Extension ──────────────────────────────
function submitExt() {
  clearErr();
  let ok = true;
  const num  = document.getElementById('f-number').value.trim();
  const pass = document.getElementById('f-password').value;
  const name = document.getElementById('f-name').value.trim();

  if (!/^\d{3,6}$/.test(num)) {
    document.getElementById('err-number').textContent='৩-৬ ডিজিটের নম্বর দিন';
    document.getElementById('f-number').classList.add('error');
    ok=false;
  }
  if (pass.length < 4) {
    document.getElementById('err-password').textContent='কমপক্ষে ৪ অক্ষর';
    document.getElementById('f-password').classList.add('error');
    ok=false;
  }
  if (!name) {
    document.getElementById('err-name').textContent='নাম আবশ্যক';
    document.getElementById('f-name').classList.add('error');
    ok=false;
  }
  if (!ok) return;

  const btn = document.getElementById('submit-btn');
  btn.disabled=true; btn.textContent='⏳ সংরক্ষণ হচ্ছে...';

  post({
    action: document.getElementById('form-action').value,
    number: num,
    password: pass,
    name: name,
    email: document.getElementById('f-email').value,
    context: document.getElementById('f-context').value,
    callgroup: document.getElementById('f-callgroup').value,
    voicemail: document.getElementById('f-voicemail').checked ? 'true':'false'
  }).then(d=>{
    if(d.ok){showToast(d.msg);closeModal();setTimeout(()=>location.reload(),1200);}
    else showToast(d.msg,'error');
  }).catch(()=>showToast('সার্ভার ত্রুটি!','error'))
  .finally(()=>{btn.disabled=false;btn.innerHTML='💾 <span id="submit-txt">সংরক্ষণ করুন</span>';});
}

// ── Delete ────────────────────────────────────────
let DEL_NUM='';
function confirmDelete(num,name){
  DEL_NUM=num;
  document.getElementById('del-num').textContent=num;
  document.getElementById('del-name').textContent=name;
  document.getElementById('del-modal').classList.add('open');
}
function closeDelModal(){document.getElementById('del-modal').classList.remove('open');}
function doDelete(){
  post({action:'delete',number:DEL_NUM}).then(d=>{
    closeDelModal();
    if(d.ok){showToast(d.msg);setTimeout(()=>location.reload(),1200);}
    else showToast(d.msg,'error');
  });
}

// ── Search / Filter ───────────────────────────────
let CUR_F='all';
function setF(f,el){
  CUR_F=f;
  document.querySelectorAll('.pill').forEach(p=>p.classList.remove('active'));
  el.classList.add('active');
  filterExts();
}
function filterExts(){
  const q=document.getElementById('ext-search').value.toLowerCase();
  document.querySelectorAll('#ext-tbody tr[data-n]').forEach(row=>{
    const mn=row.dataset.n||'';
    const nm=row.dataset.nm||'';
    const ms=row.dataset.s||'';
    const mq=mn.includes(q)||nm.includes(q);
    const mf=CUR_F==='all'||ms===CUR_F;
    row.style.display=(mq&&mf)?'':'none';
  });
}

// ── Overlay close on bg click ─────────────────────
document.querySelectorAll('.overlay').forEach(o=>{
  o.addEventListener('click',e=>{
    if(e.target===o){
      o.classList.remove('open');
      document.getElementById('f-number').readOnly=false;
    }
  });
});
</script>
</body>
</html>

import React, { useState } from 'react';
import {
  Phone, Plus, Edit2, Trash2, RefreshCw, Server, Users, Activity,
  CheckCircle, XCircle, AlertCircle, Globe, Lock, Eye, EyeOff,
  Settings, ChevronRight, BarChart2, Wifi, WifiOff, Shield,
  Download, Search, X, Save, Info, Terminal
} from 'lucide-react';

// ===================== TYPES =====================
interface Extension {
  id: string;
  number: string;
  password: string;
  name: string;
  email: string;
  context: string;
  voicemail: boolean;
  callgroup: string;
  status: 'registered' | 'unregistered' | 'unknown';
  ua?: string;
  ip?: string;
}

interface Trunk {
  name: string;
  state: string;
  type: string;
  calls: string;
}

interface SystemStatus {
  version: string;
  uptime: string;
  sessions: string;
  sessionRate: string;
  maxSessions: string;
  coreUUID: string;
}

// ===================== MOCK DATA =====================
const mockExtensions: Extension[] = [
  { id: '1', number: '1001', password: 'pass1001', name: 'Alice Rahman', email: 'alice@example.com', context: 'default', voicemail: true, callgroup: 'sales', status: 'registered', ua: 'Zoiper5', ip: '192.168.1.10' },
  { id: '2', number: '1002', password: 'pass1002', name: 'Bob Hossain', email: 'bob@example.com', context: 'default', voicemail: true, callgroup: 'support', status: 'registered', ua: 'Linphone', ip: '192.168.1.11' },
  { id: '3', number: '1003', password: 'pass1003', name: 'Carol Islam', email: 'carol@example.com', context: 'default', voicemail: false, callgroup: 'sales', status: 'unregistered', ua: '', ip: '' },
  { id: '4', number: '1004', password: 'pass1004', name: 'David Ahmed', email: 'david@example.com', context: 'default', voicemail: true, callgroup: 'management', status: 'registered', ua: 'MicroSIP', ip: '192.168.1.14' },
  { id: '5', number: '1005', password: 'pass1005', name: 'Eva Begum', email: 'eva@example.com', context: 'default', voicemail: false, callgroup: 'support', status: 'unregistered', ua: '', ip: '' },
  { id: '6', number: '1006', password: 'pass1006', name: 'Farhan Khan', email: 'farhan@example.com', context: 'default', voicemail: true, callgroup: 'sales', status: 'registered', ua: 'Bria', ip: '192.168.1.20' },
];

const mockTrunks: Trunk[] = [
  { name: 'trunk-carrier1', state: 'RUNNING', type: 'Gateway', calls: '3' },
  { name: 'trunk-carrier2', state: 'RUNNING', type: 'Gateway', calls: '1' },
  { name: 'trunk-pstn', state: 'DOWN', type: 'Gateway', calls: '0' },
  { name: 'trunk-voip-bd', state: 'RUNNING', type: 'Gateway', calls: '5' },
  { name: 'internal', state: 'RUNNING', type: 'profile', calls: '9' },
  { name: 'external', state: 'RUNNING', type: 'profile', calls: '2' },
];

const mockSystemStatus: SystemStatus = {
  version: 'FreeSWITCH 1.10.12 (git-b91a0a6 2024-08-01)',
  uptime: '5 days 14:32:10',
  sessions: '12',
  sessionRate: '2.5',
  maxSessions: '1000',
  coreUUID: 'a7f3c2d1-4b5e-6f7a-8c9d-0e1f2a3b4c5d',
};

const phpInstallCode = `# ১. ফাইল কপি করুন
cp fs_manager.php /var/www/html/fs_manager.php

# ২. FreeSWITCH ESL সক্রিয় করুন
fs_cli -x "load mod_event_socket"

# ৩. Directory পার্মিশন দিন
chmod 775 /etc/freeswitch/directory/default
chown -R www-data:freeswitch /etc/freeswitch/directory/default

# ৪. Apache/Nginx PHP সক্রিয় করুন
apt install php libapache2-mod-php -y
a2enmod php8.x

# ৫. ব্রাউজারে যান
http://YOUR_SERVER_IP/fs_manager.php
# ডিফল্ট পাসওয়ার্ড: admin123`;

// ===================== COMPONENTS =====================

const StatCard = ({ icon: Icon, label, value, color, subtext }: { icon: React.ElementType; label: string; value: string | number; color: string; subtext?: string }) => (
  <div className="bg-slate-800 border border-slate-700 rounded-2xl p-5 flex items-start gap-4 hover:border-slate-600 hover:shadow-lg transition-all duration-200">
    <div className={`p-3 rounded-xl ${color}`}>
      <Icon size={22} className="text-white" />
    </div>
    <div className="flex-1 min-w-0">
      <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-bold text-white mt-0.5">{value}</p>
      {subtext && <p className="text-xs text-slate-500 mt-0.5">{subtext}</p>}
    </div>
  </div>
);

const StatusBadge = ({ status }: { status: string }) => {
  const cfg: Record<string, { cls: string; icon: React.ReactNode }> = {
    registered: { cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: <CheckCircle size={11} /> },
    unregistered: { cls: 'bg-red-500/15 text-red-400 border-red-500/30', icon: <XCircle size={11} /> },
    unknown: { cls: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/30', icon: <AlertCircle size={11} /> },
    RUNNING: { cls: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30', icon: <CheckCircle size={11} /> },
    DOWN: { cls: 'bg-red-500/15 text-red-400 border-red-500/30', icon: <XCircle size={11} /> },
  };
  const s = cfg[status] || cfg.unknown;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border ${s.cls}`}>
      {s.icon} {status}
    </span>
  );
};

// ===================== EXTENSION FORM MODAL =====================
const ExtensionModal = ({
  ext,
  onSave,
  onClose,
}: {
  ext?: Extension | null;
  onSave: (e: Extension) => void;
  onClose: () => void;
}) => {
  const [form, setForm] = useState<Extension>(
    ext || {
      id: Date.now().toString(),
      number: '',
      password: '',
      name: '',
      email: '',
      context: 'default',
      voicemail: true,
      callgroup: '',
      status: 'unregistered',
    }
  );
  const [showPass, setShowPass] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!form.number || !/^\d{3,6}$/.test(form.number)) errs.number = 'এক্সটেনশন নম্বর ৩-৬ ডিজিটের হতে হবে';
    if (!form.password || form.password.length < 4) errs.password = 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষর হতে হবে';
    if (!form.name) errs.name = 'নাম আবশ্যক';
    return errs;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    onSave(form);
  };

  const xmlPreview = `<?xml version="1.0" encoding="UTF-8"?>
<include>
  <user id="${form.number || 'XXXX'}">
    <params>
      <param name="password" value="●●●●●●"/>
      <param name="vm-password" value="●●●●●●"/>
    </params>
    <variables>
      <variable name="toll_allow" value="domestic,international,local"/>
      <variable name="accountcode" value="${form.number || 'XXXX'}"/>
      <variable name="user_context" value="${form.context}"/>
      <variable name="effective_caller_id_name" value="${form.name || 'User Name'}"/>
      <variable name="effective_caller_id_number" value="${form.number || 'XXXX'}"/>
      <variable name="callgroup" value="${form.callgroup || 'default'}"/>
      <variable name="vm-enabled" value="${form.voicemail ? 'true' : 'false'}"/>
      <variable name="vm-mailto" value="${form.email || ''}"/>
    </variables>
  </user>
</include>`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-violet-600 rounded-t-3xl p-5 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-xl"><Phone size={18} className="text-white" /></div>
            <div>
              <h2 className="text-white font-bold text-base">{ext ? `Extension সম্পাদনা — ${ext.number}` : 'নতুন Extension যোগ'}</h2>
              <p className="text-blue-100 text-xs">FreeSWITCH Directory Configuration</p>
            </div>
          </div>
          <button onClick={onClose} className="bg-white/20 hover:bg-white/30 text-white rounded-xl p-2 transition-colors">
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Extension নম্বর <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={form.number}
                  onChange={e => setForm({ ...form, number: e.target.value })}
                  readOnly={!!ext}
                  placeholder="যেমন: 1001"
                  className={`w-full pl-9 pr-4 py-2.5 rounded-xl border text-sm font-mono bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.number ? 'border-red-500' : 'border-slate-600'} ${ext ? 'opacity-60 cursor-not-allowed' : ''}`}
                />
              </div>
              {errors.number && <p className="text-red-400 text-xs mt-1">{errors.number}</p>}
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                SIP পাসওয়ার্ড <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <Lock size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type={showPass ? 'text' : 'password'}
                  value={form.password}
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  placeholder="শক্তিশালী পাসওয়ার্ড"
                  className={`w-full pl-9 pr-10 py-2.5 rounded-xl border text-sm font-mono bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.password ? 'border-red-500' : 'border-slate-600'}`}
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                  {showPass ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
              {errors.password && <p className="text-red-400 text-xs mt-1">{errors.password}</p>}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              প্রদর্শন নাম <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <Users size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="text"
                value={form.name}
                onChange={e => setForm({ ...form, name: e.target.value })}
                placeholder="যেমন: Alice Rahman"
                className={`w-full pl-9 pr-4 py-2.5 rounded-xl border text-sm bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.name ? 'border-red-500' : 'border-slate-600'}`}
              />
            </div>
            {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">ইমেইল (Voicemail Notification)</label>
            <input
              type="email"
              value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })}
              placeholder="user@example.com"
              className="w-full px-4 py-2.5 rounded-xl border border-slate-600 text-sm bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Context</label>
              <select
                value={form.context}
                onChange={e => setForm({ ...form, context: e.target.value })}
                className="w-full px-4 py-2.5 rounded-xl border border-slate-600 text-sm bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="default">default</option>
                <option value="public">public</option>
                <option value="internal">internal</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Call Group</label>
              <input
                type="text"
                value={form.callgroup}
                onChange={e => setForm({ ...form, callgroup: e.target.value })}
                placeholder="sales, support..."
                className="w-full px-4 py-2.5 rounded-xl border border-slate-600 text-sm bg-slate-900 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          <div className="flex items-center justify-between bg-slate-900 rounded-xl p-4 border border-slate-700">
            <div>
              <p className="text-sm font-semibold text-white">Voicemail সক্রিয়</p>
              <p className="text-xs text-slate-500">মিসড কল হলে ভয়েসমেইল সংরক্ষণ হবে</p>
            </div>
            <button
              type="button"
              onClick={() => setForm({ ...form, voicemail: !form.voicemail })}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${form.voicemail ? 'bg-blue-600' : 'bg-slate-600'}`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform shadow ${form.voicemail ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
          </div>

          <div className="bg-slate-900 border border-blue-500/20 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <Terminal size={12} className="text-blue-400" />
              <span className="text-blue-400 text-xs font-mono">/etc/freeswitch/directory/default/{form.number || 'XXXX'}.xml</span>
            </div>
            <pre className="text-xs text-slate-400 font-mono overflow-x-auto leading-relaxed whitespace-pre-wrap">{xmlPreview}</pre>
          </div>

          <div className="flex gap-3 pt-1">
            <button type="button" onClick={onClose}
              className="flex-1 py-3 rounded-xl border border-slate-600 text-slate-300 font-semibold hover:bg-slate-700 transition-colors text-sm">
              বাতিল
            </button>
            <button type="submit"
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 text-white font-semibold hover:from-blue-700 hover:to-violet-700 transition-all text-sm flex items-center justify-center gap-2 shadow-lg">
              <Save size={15} />
              {ext ? 'আপডেট করুন' : 'সংরক্ষণ করুন'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ===================== DELETE CONFIRM =====================
const DeleteConfirm = ({ ext, onConfirm, onClose }: { ext: Extension; onConfirm: () => void; onClose: () => void }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
    <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
    <div className="relative bg-slate-800 border border-slate-700 rounded-3xl shadow-2xl w-full max-w-sm p-8 text-center">
      <div className="text-5xl mb-4">⚠️</div>
      <h3 className="text-xl font-bold text-white mb-2">Extension মুছবেন?</h3>
      <p className="text-slate-400 text-sm mb-1">
        Extension <span className="font-mono font-bold text-blue-400">{ext.number}</span> ({ext.name})
      </p>
      <p className="text-xs text-red-400 mb-6 bg-red-500/10 border border-red-500/20 rounded-xl px-4 py-2">
        XML ফাইলটি স্থায়ীভাবে মুছে যাবে এবং FreeSWITCH reloadxml হবে
      </p>
      <div className="flex gap-3">
        <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-slate-600 text-slate-300 font-semibold hover:bg-slate-700 text-sm">বাতিল</button>
        <button onClick={onConfirm} className="flex-1 py-2.5 rounded-xl bg-red-600 text-white font-semibold hover:bg-red-700 text-sm">✓ হ্যাঁ, মুছুন</button>
      </div>
    </div>
  </div>
);

// ===================== MAIN APP =====================
export default function App() {
  type TabId = 'dashboard' | 'extensions' | 'trunks' | 'status' | 'install';
  const [tab, setTab] = useState<TabId>('dashboard');
  const [extensions, setExtensions] = useState<Extension[]>(mockExtensions);
  const [trunks] = useState<Trunk[]>(mockTrunks);
  const [sysStatus] = useState<SystemStatus>(mockSystemStatus);
  const [showModal, setShowModal] = useState(false);
  const [editExt, setEditExt] = useState<Extension | null>(null);
  const [deleteExt, setDeleteExt] = useState<Extension | null>(null);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  const handleSave = (ext: Extension) => {
    if (editExt) {
      setExtensions(prev => prev.map(e => e.id === ext.id ? ext : e));
      showToast(`✅ Extension ${ext.number} সফলভাবে আপডেট হয়েছে`);
    } else {
      setExtensions(prev => [...prev, ext]);
      showToast(`✅ Extension ${ext.number} সফলভাবে যোগ হয়েছে`);
    }
    setShowModal(false);
    setEditExt(null);
  };

  const handleDelete = (ext: Extension) => {
    setExtensions(prev => prev.filter(e => e.id !== ext.id));
    setDeleteExt(null);
    showToast(`🗑️ Extension ${ext.number} মুছে ফেলা হয়েছে`, 'error');
  };

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => { setRefreshing(false); showToast('✅ ডেটা রিফ্রেশ হয়েছে'); }, 1500);
  };

  const filtered = extensions.filter(e => {
    const matchSearch = e.number.includes(search) || e.name.toLowerCase().includes(search.toLowerCase()) || e.email.toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === 'all' || e.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const registeredCount = extensions.filter(e => e.status === 'registered').length;
  const unregisteredCount = extensions.filter(e => e.status === 'unregistered').length;
  const runningTrunks = trunks.filter(t => t.state === 'RUNNING').length;
  const totalCalls = trunks.reduce((s, t) => s + parseInt(t.calls), 0);

  const tabs: { id: TabId; label: string; icon: React.ReactNode }[] = [
    { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: <BarChart2 size={16} /> },
    { id: 'extensions', label: 'Extension তালিকা', icon: <Users size={16} /> },
    { id: 'trunks', label: 'Trunk / Gateway', icon: <Globe size={16} /> },
    { id: 'status', label: 'সিস্টেম স্ট্যাটাস', icon: <Activity size={16} /> },
    { id: 'install', label: 'ইনস্টলেশন গাইড', icon: <Terminal size={16} /> },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-5 right-5 z-[999] flex items-center gap-3 px-5 py-3.5 rounded-2xl text-sm font-semibold shadow-2xl transition-all ${toast.type === 'success' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}>
          {toast.type === 'success' ? <CheckCircle size={16} /> : <XCircle size={16} />}
          {toast.msg}
        </div>
      )}

      {/* Modals */}
      {showModal && <ExtensionModal ext={editExt} onSave={handleSave} onClose={() => { setShowModal(false); setEditExt(null); }} />}
      {deleteExt && <DeleteConfirm ext={deleteExt} onConfirm={() => handleDelete(deleteExt)} onClose={() => setDeleteExt(null)} />}

      {/* ── Sidebar ── */}
      <div className="fixed left-0 top-0 h-full w-64 bg-slate-900 border-r border-slate-800 z-40 flex flex-col">
        <div className="p-5 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-violet-600 rounded-xl flex items-center justify-center text-xl shadow-lg shadow-blue-500/30">📞</div>
            <div>
              <h1 className="text-white font-bold text-base leading-tight">FreeSWITCH</h1>
              <p className="text-slate-500 text-xs">Extension Manager</p>
            </div>
          </div>
        </div>

        {/* ESL Status */}
        <div className="px-5 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-3 py-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400" />
            <span className="text-xs text-emerald-400 font-semibold">FreeSWITCH Engine</span>
            <span className="ml-auto text-xs text-emerald-500 font-bold">LIVE</span>
          </div>
          <div className="mt-2 text-xs text-slate-600 text-center font-mono">ESL: 127.0.0.1:8021</div>
        </div>

        {/* Nav */}
        <nav className="flex-1 p-3 space-y-1">
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${tab === t.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
              {t.icon}
              <span className="flex-1 text-left">{t.label}</span>
              {t.id === 'extensions' && <span className="bg-slate-700 text-slate-300 text-xs px-2 py-0.5 rounded-full">{extensions.length}</span>}
              {t.id === 'trunks' && <span className="bg-slate-700 text-slate-300 text-xs px-2 py-0.5 rounded-full">{trunks.length}</span>}
            </button>
          ))}
        </nav>

        {/* Config info */}
        <div className="p-4 border-t border-slate-800">
          <div className="bg-slate-800 rounded-xl p-3 text-xs text-slate-500 space-y-1.5">
            <div className="flex justify-between"><span>Directory</span><span className="text-slate-400 font-mono">/etc/freeswitch/...</span></div>
            <div className="flex justify-between"><span>Extensions</span><span className="text-emerald-400 font-bold">{extensions.length} টি</span></div>
            <div className="flex justify-between"><span>Registered</span><span className="text-emerald-400 font-bold">{registeredCount} টি</span></div>
          </div>
        </div>
      </div>

      {/* ── Main ── */}
      <div className="ml-64 flex-1 flex flex-col min-h-screen">
        {/* Topbar */}
        <div className="sticky top-0 z-30 bg-slate-900/80 backdrop-blur-sm border-b border-slate-800 px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm">
            <ChevronRight size={14} className="text-slate-600" />
            <span className="text-white font-semibold">{tabs.find(t => t.id === tab)?.label}</span>
          </div>
          <div className="flex items-center gap-2.5">
            <button onClick={handleRefresh} className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-2 rounded-xl text-xs font-medium transition-colors border border-slate-700">
              <RefreshCw size={13} className={refreshing ? 'animate-spin' : ''} />
              Refresh
            </button>
            <button
              onClick={() => { setEditExt(null); setShowModal(true); }}
              className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-violet-600 hover:from-blue-700 hover:to-violet-700 text-white px-4 py-2 rounded-xl text-xs font-semibold shadow-lg shadow-blue-600/25 transition-all">
              <Plus size={13} />
              নতুন Extension
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 flex-1">

          {/* ── DASHBOARD ── */}
          {tab === 'dashboard' && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                <StatCard icon={Users} label="মোট Extension" value={extensions.length} color="bg-blue-600" subtext="কনফিগার করা" />
                <StatCard icon={CheckCircle} label="রেজিস্টার্ড" value={registeredCount} color="bg-emerald-600" subtext="সক্রিয় SIP" />
                <StatCard icon={XCircle} label="আনরেজিস্টার্ড" value={unregisteredCount} color="bg-red-600" subtext="অফলাইন" />
                <StatCard icon={Globe} label="Trunk সক্রিয়" value={`${runningTrunks}/${trunks.length}`} color="bg-violet-600" subtext="Gateway Running" />
                <StatCard icon={Phone} label="সক্রিয় কল" value={totalCalls} color="bg-orange-600" subtext="বর্তমান" />
              </div>

              {/* FS Info */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
                  <h3 className="text-white font-bold flex items-center gap-2">
                    <Server size={16} className="text-blue-400" />
                    FreeSWITCH সিস্টেম তথ্য
                  </h3>
                  <span className="text-xs bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 px-3 py-1 rounded-full font-bold">● RUNNING</span>
                </div>
                <div className="p-5 grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    ['ভার্সন', sysStatus.version],
                    ['আপটাইম', sysStatus.uptime],
                    ['সক্রিয় সেশন', sysStatus.sessions],
                    ['সেশন রেট', sysStatus.sessionRate + '/sec'],
                    ['সর্বোচ্চ সেশন', sysStatus.maxSessions],
                    ['Core UUID', sysStatus.coreUUID.slice(0, 20) + '...'],
                  ].map(([k, v]) => (
                    <div key={k} className="bg-slate-800 rounded-xl px-4 py-3 border border-slate-700">
                      <p className="text-slate-500 text-xs mb-1">{k}</p>
                      <p className="text-white text-sm font-semibold font-mono truncate">{v}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Extensions */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex justify-between items-center">
                  <h3 className="text-white font-bold flex items-center gap-2">
                    <Phone size={16} className="text-blue-400" />
                    সাম্প্রতিক Extension
                  </h3>
                  <button onClick={() => setTab('extensions')} className="text-blue-400 text-xs hover:text-blue-300 font-medium">সব দেখুন →</button>
                </div>
                <div className="divide-y divide-slate-800">
                  {extensions.slice(0, 5).map(e => (
                    <div key={e.id} className="flex items-center justify-between px-5 py-3 hover:bg-slate-800/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 bg-blue-600/15 border border-blue-500/20 rounded-xl flex items-center justify-center">
                          <span className="text-blue-400 font-bold text-xs font-mono">{e.number}</span>
                        </div>
                        <div>
                          <p className="text-white font-semibold text-sm">{e.name}</p>
                          <p className="text-slate-600 text-xs">{e.callgroup}</p>
                        </div>
                      </div>
                      <StatusBadge status={e.status} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Trunk Overview */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex justify-between items-center">
                  <h3 className="text-white font-bold flex items-center gap-2">
                    <Globe size={16} className="text-violet-400" />
                    Trunk / Gateway অবস্থা
                  </h3>
                  <button onClick={() => setTab('trunks')} className="text-violet-400 text-xs hover:text-violet-300 font-medium">সব দেখুন →</button>
                </div>
                <div className="divide-y divide-slate-800">
                  {trunks.slice(0, 4).map(t => (
                    <div key={t.name} className="flex items-center justify-between px-5 py-3">
                      <div className="flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${t.state === 'RUNNING' ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
                        <span className="text-white font-mono text-sm font-semibold">{t.name}</span>
                        <span className="text-slate-600 text-xs">{t.type}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-slate-400 text-xs">{t.calls} কল</span>
                        <StatusBadge status={t.state} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── EXTENSIONS ── */}
          {tab === 'extensions' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
                <h3 className="text-white font-bold flex items-center gap-2">
                  <Users size={16} className="text-blue-400" />
                  Extension তালিকা
                </h3>
                <button
                  onClick={() => { setEditExt(null); setShowModal(true); }}
                  className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-xl text-xs font-semibold transition-colors">
                  <Plus size={13} /> নতুন Extension যোগ
                </button>
              </div>

              {/* Search + Filter */}
              <div className="px-5 py-3 border-b border-slate-800 flex gap-3 flex-wrap">
                <div className="relative flex-1 min-w-48">
                  <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" />
                  <input
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                    placeholder="নম্বর বা নাম খুঁজুন..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div className="flex gap-2">
                  {['all', 'registered', 'unregistered'].map(f => (
                    <button key={f} onClick={() => setFilterStatus(f)}
                      className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-colors ${filterStatus === f ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'}`}>
                      {f === 'all' ? 'সব' : f === 'registered' ? '● রেজিস্টার্ড' : '○ আনরেজিস্টার্ড'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-black/20">
                    <tr>
                      {['Ext #', 'নাম / ইমেইল', 'Context', 'Call Group', 'Voicemail', 'স্ট্যাটাস', 'IP / UA', 'কার্যক্রম'].map(h => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-bold text-slate-500 uppercase tracking-wider whitespace-nowrap border-b border-slate-800">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50">
                    {filtered.map(e => (
                      <tr key={e.id} className="hover:bg-slate-800/30 transition-colors group">
                        <td className="px-4 py-3">
                          <span className="text-blue-400 font-bold font-mono text-base">{e.number}</span>
                        </td>
                        <td className="px-4 py-3">
                          <p className="text-white font-semibold">{e.name}</p>
                          <p className="text-slate-600 text-xs">{e.email || '—'}</p>
                        </td>
                        <td className="px-4 py-3">
                          <span className="bg-blue-500/15 text-blue-400 border border-blue-500/25 text-xs px-2 py-1 rounded-lg font-mono">{e.context}</span>
                        </td>
                        <td className="px-4 py-3 text-slate-500 text-xs">{e.callgroup || '—'}</td>
                        <td className="px-4 py-3">
                          <span className={`text-xs px-2.5 py-1 rounded-full font-bold border ${e.voicemail ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/25' : 'bg-slate-700/50 text-slate-500 border-slate-700'}`}>
                            {e.voicemail ? '✓ সক্রিয়' : '✗ বন্ধ'}
                          </span>
                        </td>
                        <td className="px-4 py-3"><StatusBadge status={e.status} /></td>
                        <td className="px-4 py-3">
                          {e.ip ? (
                            <div>
                              <p className="text-slate-300 text-xs font-mono">{e.ip}</p>
                              <p className="text-slate-600 text-xs">{e.ua}</p>
                            </div>
                          ) : <span className="text-slate-700 text-xs">—</span>}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => { setEditExt(e); setShowModal(true); }}
                              className="flex items-center gap-1.5 bg-blue-600/15 hover:bg-blue-600 text-blue-400 hover:text-white px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all border border-blue-500/25 hover:border-blue-600">
                              <Edit2 size={11} /> সম্পাদনা
                            </button>
                            <button
                              onClick={() => setDeleteExt(e)}
                              className="flex items-center gap-1.5 bg-red-600/15 hover:bg-red-600 text-red-400 hover:text-white px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all border border-red-500/25 hover:border-red-600">
                              <Trash2 size={11} /> মুছুন
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {filtered.length === 0 && (
                      <tr>
                        <td colSpan={8} className="text-center py-14 text-slate-600">
                          <Users size={36} className="mx-auto mb-3 opacity-30" />
                          <p className="font-semibold">কোনো Extension পাওয়া যায়নি</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              <div className="px-5 py-3 border-t border-slate-800 text-xs text-slate-600">
                মোট <span className="text-white font-bold">{filtered.length}</span> টি দেখাচ্ছে / <span className="text-white font-bold">{extensions.length}</span> টি Extension — <span className="font-mono">/etc/freeswitch/directory/default/</span>
              </div>
            </div>
          )}

          {/* ── TRUNKS ── */}
          {tab === 'trunks' && (
            <div className="space-y-5">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard icon={Wifi} label="Running Trunk" value={runningTrunks} color="bg-emerald-600" subtext="সক্রিয়" />
                <StatCard icon={WifiOff} label="Down Trunk" value={trunks.filter(t => t.state === 'DOWN').length} color="bg-red-600" subtext="বন্ধ" />
                <StatCard icon={Globe} label="মোট Trunk" value={trunks.length} color="bg-violet-600" subtext="Gateway" />
                <StatCard icon={Activity} label="সক্রিয় কল" value={totalCalls} color="bg-orange-600" subtext="Trunk কল" />
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
                  <h3 className="text-white font-bold flex items-center gap-2">
                    <Globe size={16} className="text-violet-400" />
                    Trunk / Sofia Profile স্ট্যাটাস
                  </h3>
                  <code className="text-slate-600 text-xs font-mono">sofia status</code>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-black/20">
                      <tr>
                        {['Trunk / Profile নাম', 'ধরন', 'সক্রিয় কল', 'স্ট্যাটাস'].map(h => (
                          <th key={h} className="px-5 py-3 text-left text-xs font-bold text-slate-500 uppercase border-b border-slate-800">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/50">
                      {trunks.map(t => (
                        <tr key={t.name} className="hover:bg-slate-800/30">
                          <td className="px-5 py-4">
                            <div className="flex items-center gap-3">
                              <div className={`w-2 h-2 rounded-full flex-shrink-0 ${t.state === 'RUNNING' ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
                              <span className="text-white font-semibold font-mono">{t.name}</span>
                            </div>
                          </td>
                          <td className="px-5 py-4">
                            <span className="bg-violet-500/15 text-violet-400 border border-violet-500/25 text-xs px-2.5 py-1 rounded-lg">{t.type}</span>
                          </td>
                          <td className="px-5 py-4">
                            <span className="text-white font-bold text-lg">{t.calls}</span>
                            <span className="text-slate-600 text-xs ml-1">কল</span>
                          </td>
                          <td className="px-5 py-4">
                            <StatusBadge status={t.state} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Raw sofia output simulation */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex items-center gap-2">
                  <Terminal size={16} className="text-green-400" />
                  <h3 className="text-white font-bold">Raw sofia status Output</h3>
                </div>
                <div className="p-5">
                  <pre className="bg-black rounded-xl p-4 text-green-400 font-mono text-xs leading-relaxed overflow-x-auto border border-green-900/30">
{`                     Name      Type                                          Data      State
=================================================================================
                 internal  profile                 sip:mod_sofia@192.168.1.1:5060    RUNNING (0)
                 external  profile                5080 sip:mod_sofia@0.0.0.0:5080    RUNNING (0)
         trunk-carrier1    gateway          sip:trunk-carrier1@sip.carrier1.com       RUNNING (0)
         trunk-carrier2    gateway          sip:trunk-carrier2@sip.carrier2.com       RUNNING (0)
            trunk-pstn     gateway               sip:trunk-pstn@sip.pstn.net:5060         DOWN
         trunk-voip-bd     gateway             sip:trunk-voip-bd@voip.bd.net:5060    RUNNING (0)
=================================================================================
5 profiles 4 aliases`}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* ── STATUS ── */}
          {tab === 'status' && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <h4 className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Server size={14} className="text-blue-400" /> সিস্টেম তথ্য
                  </h4>
                  {[
                    ['ভার্সন', sysStatus.version],
                    ['আপটাইম', sysStatus.uptime],
                    ['সক্রিয় সেশন', sysStatus.sessions],
                    ['সেশন রেট', sysStatus.sessionRate + '/sec'],
                    ['সর্বোচ্চ সেশন', sysStatus.maxSessions],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between items-center py-2.5 border-b border-slate-800 last:border-0">
                      <span className="text-slate-500 text-sm">{k}</span>
                      <span className="text-white text-sm font-semibold">{v}</span>
                    </div>
                  ))}
                </div>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                  <h4 className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-4 flex items-center gap-2">
                    <Shield size={14} className="text-violet-400" /> ESL কনফিগারেশন
                  </h4>
                  {[
                    ['ESL Host', '127.0.0.1'],
                    ['ESL Port', '8021'],
                    ['Directory', '/etc/freeswitch/directory/default'],
                    ['Core UUID', sysStatus.coreUUID],
                    ['PHP ভার্সন', '8.1+'],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between items-center py-2.5 border-b border-slate-800 last:border-0">
                      <span className="text-slate-500 text-sm">{k}</span>
                      <span className="text-white text-xs font-mono truncate max-w-48">{v}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex items-center gap-2">
                  <Terminal size={16} className="text-green-400" />
                  <h3 className="text-white font-bold">FreeSWITCH Console — status</h3>
                </div>
                <div className="p-5">
                  <pre className="bg-black rounded-xl p-4 text-green-400 font-mono text-xs leading-relaxed overflow-x-auto border border-green-900/30">
{`FreeSWITCH Status
================
${sysStatus.version}
Uptime:               ${sysStatus.uptime}
Active Sessions:      ${sysStatus.sessions}
Peak Sessions:        18 at 2024-08-01 09:23:12
Last 5min:            ${sysStatus.sessionRate} sessions per second
Max sessions:         ${sysStatus.maxSessions}
Min idle cpu:         15.000000/68.600000
Core-UUID:            ${sysStatus.coreUUID}

Module: mod_sofia      (running)
Module: mod_event_socket (running)
Module: mod_voicemail  (running)
Module: mod_dialplan_xml (running)`}
                  </pre>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex items-center gap-2">
                  <Terminal size={16} className="text-green-400" />
                  <h3 className="text-white font-bold">show registrations — আউটপুট</h3>
                </div>
                <div className="p-5">
                  <pre className="bg-black rounded-xl p-4 text-green-400 font-mono text-xs leading-relaxed overflow-x-auto border border-green-900/30">
{`reg_user,realm,token,url,expires,network_ip,network_port,network_proto,hostname,metadata
1001,192.168.1.1,7c99f,sip:1001@192.168.1.10:5060,3600,192.168.1.10,5060,udp,pbx01,
1002,192.168.1.1,a3f2b,sip:1002@192.168.1.11:5060,1800,192.168.1.11,5060,udp,pbx01,
1004,192.168.1.1,e8d1c,sip:1004@192.168.1.14:5060,3600,192.168.1.14,5060,tcp,pbx01,
1006,192.168.1.1,f7a9e,sip:1006@192.168.1.20:5060,3600,192.168.1.20,5060,udp,pbx01,

4 total.`}
                  </pre>
                </div>
              </div>
            </div>
          )}

          {/* ── INSTALL ── */}
          {tab === 'install' && (
            <div className="space-y-5">
              {/* Instructions */}
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-6">
                <h4 className="text-blue-400 font-bold flex items-center gap-2 mb-4 text-base">
                  <Info size={18} /> ইনস্টলেশন নির্দেশিকা
                </h4>
                <div className="space-y-3">
                  {[
                    { step: '১', title: 'PHP ফাইল কপি করুন', desc: 'নিচের PHP কোড বা public/fs_manager.php ফাইলটি /var/www/html/fs_manager.php হিসেবে রাখুন' },
                    { step: '২', title: 'FreeSWITCH ESL সক্রিয় করুন', desc: 'mod_event_socket মডিউল লোড করুন। /etc/freeswitch/autoload_configs/event_socket.conf.xml চেক করুন' },
                    { step: '৩', title: 'Directory পার্মিশন দিন', desc: 'www-data ইউজারকে /etc/freeswitch/directory/default/ ফোল্ডারে লেখার অনুমতি দিন' },
                    { step: '৪', title: 'পাসওয়ার্ড পরিবর্তন করুন', desc: 'PHP ফাইলের ADMIN_PASS কনস্ট্যান্টটি নিরাপদ পাসওয়ার্ড দিয়ে পরিবর্তন করুন' },
                    { step: '৫', title: 'ব্রাউজারে যান', desc: 'http://YOUR_SERVER_IP/fs_manager.php — ডিফল্ট পাসওয়ার্ড: admin123' },
                  ].map(item => (
                    <div key={item.step} className="flex items-start gap-4">
                      <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0 mt-0.5">{item.step}</div>
                      <div>
                        <p className="text-white font-semibold text-sm">{item.title}</p>
                        <p className="text-slate-400 text-xs mt-0.5">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Install commands */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Terminal size={16} className="text-green-400" />
                    <h3 className="text-white font-bold">Terminal কমান্ড</h3>
                  </div>
                  <button
                    onClick={() => { navigator.clipboard.writeText(phpInstallCode); showToast('কমান্ড কপি হয়েছে!'); }}
                    className="flex items-center gap-2 bg-green-600/15 hover:bg-green-600/25 text-green-400 border border-green-500/25 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors">
                    <Download size={12} /> কপি করুন
                  </button>
                </div>
                <div className="p-5">
                  <pre className="bg-black rounded-xl p-4 text-green-400 font-mono text-xs leading-relaxed overflow-x-auto border border-green-900/30 whitespace-pre-wrap">{phpInstallCode}</pre>
                </div>
              </div>

              {/* Features */}
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
                <h4 className="text-white font-bold mb-4 flex items-center gap-2">
                  <Settings size={16} className="text-blue-400" />
                  PHP ফাইলের বৈশিষ্ট্যসমূহ
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { icon: '🔐', title: 'নিরাপদ লগিন', desc: 'Session-based authentication' },
                    { icon: '➕', title: 'Extension যোগ', desc: 'XML ফাইল স্বয়ংক্রিয় তৈরি' },
                    { icon: '✏️', title: 'Extension সম্পাদনা', desc: 'যেকোনো সেটিং পরিবর্তন' },
                    { icon: '🗑️', title: 'Extension মুছুন', desc: 'XML ফাইল সহ মুছে যাবে' },
                    { icon: '🔄', title: 'Auto Reload', desc: 'reloadxml স্বয়ংক্রিয়' },
                    { icon: '📊', title: 'Sofia Status', desc: 'Trunk/Profile দেখা' },
                    { icon: '🔗', title: 'SIP Registration', desc: 'সক্রিয় রেজিস্ট্রেশন দেখা' },
                    { icon: '📞', title: 'Active Calls', desc: 'বর্তমান কল দেখা' },
                    { icon: '🌐', title: 'ESL Connection', desc: 'Raw socket PHP ESL' },
                  ].map(f => (
                    <div key={f.title} className="bg-slate-800 rounded-xl p-4 border border-slate-700 hover:border-slate-600 transition-colors">
                      <div className="text-2xl mb-2">{f.icon}</div>
                      <p className="text-white text-sm font-semibold">{f.title}</p>
                      <p className="text-slate-500 text-xs mt-1">{f.desc}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* File location */}
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-5">
                <h4 className="text-amber-400 font-bold flex items-center gap-2 mb-3">
                  <AlertCircle size={16} /> গুরুত্বপূর্ণ নোট
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <ChevronRight size={14} className="text-amber-400 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-300">PHP ফাইলটি আছে: <code className="bg-slate-800 px-2 py-0.5 rounded text-amber-300 font-mono text-xs">public/fs_manager.php</code> — সার্ভারে কপি করুন</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <ChevronRight size={14} className="text-amber-400 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-300">ESL পোর্ট ফায়ারওয়ালে খোলা <strong className="text-white">রাখবেন না</strong> (শুধু localhost)</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <ChevronRight size={14} className="text-amber-400 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-300">ADMIN_PASS অবশ্যই পরিবর্তন করুন — ডিফল্ট: <code className="bg-slate-800 px-2 py-0.5 rounded text-red-400 font-mono text-xs">admin123</code></span>
                  </div>
                  <div className="flex items-start gap-2">
                    <ChevronRight size={14} className="text-amber-400 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-300">FreeSWITCH ইনস্টল পথ ভিন্ন হলে FS_DIR পরিবর্তন করুন</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

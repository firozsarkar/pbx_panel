import { useState, useCallback } from 'react';
import type { Gateway, GatewayFormData } from '../types/gateway';

const STORAGE_KEY = 'fs_gateways';

function loadFromStorage(): Gateway[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveToStorage(gateways: Gateway[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(gateways));
}

export function useGatewayStore() {
  const [gateways, setGateways] = useState<Gateway[]>(loadFromStorage);

  const addGateway = useCallback((data: GatewayFormData): Gateway => {
    const newGw: Gateway = {
      ...data,
      id: `gw_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setGateways(prev => {
      const updated = [...prev, newGw];
      saveToStorage(updated);
      return updated;
    });
    return newGw;
  }, []);

  const updateGateway = useCallback((id: string, data: Partial<GatewayFormData>) => {
    setGateways(prev => {
      const updated = prev.map(gw =>
        gw.id === id ? { ...gw, ...data, updatedAt: new Date().toISOString() } : gw
      );
      saveToStorage(updated);
      return updated;
    });
  }, []);

  const deleteGateway = useCallback((id: string) => {
    setGateways(prev => {
      const updated = prev.filter(gw => gw.id !== id);
      saveToStorage(updated);
      return updated;
    });
  }, []);

  const duplicateGateway = useCallback((id: string) => {
    setGateways(prev => {
      const gw = prev.find(g => g.id === id);
      if (!gw) return prev;
      const newGw: Gateway = {
        ...gw,
        id: `gw_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        name: `${gw.name}_copy`,
        status: 'unknown',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const updated = [...prev, newGw];
      saveToStorage(updated);
      return updated;
    });
  }, []);

  const toggleStatus = useCallback((id: string) => {
    setGateways(prev => {
      const updated = prev.map(gw =>
        gw.id === id
          ? {
              ...gw,
              status: (gw.status === 'active' ? 'inactive' : 'active') as Gateway['status'],
              updatedAt: new Date().toISOString(),
            }
          : gw
      );
      saveToStorage(updated);
      return updated;
    });
  }, []);

  const importGateways = useCallback((data: Gateway[]) => {
    setGateways(() => {
      saveToStorage(data);
      return data;
    });
  }, []);

  return {
    gateways,
    addGateway,
    updateGateway,
    deleteGateway,
    duplicateGateway,
    toggleStatus,
    importGateways,
  };
}

import { useState } from 'react';
import type { Gateway, GatewayFormData } from './types/gateway';
import { useGatewayStore } from './store/gatewayStore';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import GatewayCard from './components/GatewayCard';
import GatewayForm from './components/GatewayForm';
import XmlModal from './components/XmlModal';
import ScriptsPage from './components/ScriptsPage';
import HelpGuide from './components/HelpGuide';

type Tab = 'dashboard' | 'gateways' | 'add' | 'scripts' | 'help';

export default function App() {
  const { gateways, addGateway, updateGateway, deleteGateway, duplicateGateway, toggleStatus, importGateways } = useGatewayStore();
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [editingGw, setEditingGw] = useState<Gateway | null>(null);
  const [xmlViewGw, setXmlViewGw] = useState<Gateway | null>(null);
  const [search, setSearch] = useState('');
  const [filterProfile, setFilterProfile] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [importError, setImportError] = useState('');

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleAddOrUpdate = (data: GatewayFormData) => {
    if (editingGw) {
      updateGateway(editingGw.id, data);
      showToast(`✅ "${data.name}" gateway আপডেট হয়েছে`);
      setEditingGw(null);
    } else {
      addGateway(data);
      showToast(`✅ "${data.name}" gateway যোগ হয়েছে`);
    }
    setActiveTab('gateways');
  };

  const handleEdit = (gw: Gateway) => {
    setEditingGw(gw);
    setActiveTab('add');
  };

  const handleDelete = (id: string) => {
    const gw = gateways.find(g => g.id === id);
    deleteGateway(id);
    showToast(`🗑️ "${gw?.name}" ডিলিট হয়েছে`);
  };

  const handleCancel = () => {
    setEditingGw(null);
    setActiveTab(gateways.length > 0 ? 'gateways' : 'dashboard');
  };

  const exportData = () => {
    const blob = new Blob([JSON.stringify(gateways, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `fs_gateways_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast('📤 Gateways exported successfully');
  };

  const importData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        if (Array.isArray(data)) {
          importGateways(data);
          showToast(`📥 ${data.length} টি gateway import হয়েছে`);
          setImportError('');
        } else {
          setImportError('Invalid format - JSON array expected');
        }
      } catch {
        setImportError('Invalid JSON file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const filteredGateways = gateways.filter(gw => {
    const q = search.toLowerCase();
    const matchSearch = !q || gw.name.toLowerCase().includes(q) || gw.realm.toLowerCase().includes(q) || gw.username.toLowerCase().includes(q);
    const matchProfile = filterProfile === 'all' || gw.sipProfile === filterProfile;
    const matchStatus = filterStatus === 'all' || gw.status === filterStatus;
    return matchSearch && matchProfile && matchStatus;
  });

  const activeCount = gateways.filter(g => g.status === 'active').length;

  const navTab = (tab: Tab) => {
    setActiveTab(tab);
    setEditingGw(null);
    setSidebarOpen(false);
  };

  return (
    <div className="flex h-screen overflow-hidden bg-gray-950 text-gray-100">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/60 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 transition-transform lg:relative lg:translate-x-0 lg:z-auto ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <Sidebar
          activeTab={activeTab}
          setActiveTab={(tab) => navTab(tab as Tab)}
          gatewayCount={gateways.length}
          activeCount={activeCount}
        />
      </div>

      {/* Main Content */}
      <div className="flex flex-1 flex-col overflow-hidden min-w-0">
        {/* Top Bar */}
        <header className="flex shrink-0 items-center justify-between border-b border-gray-700/60 bg-gray-900/80 backdrop-blur px-4 py-3 lg:px-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(v => !v)}
              className="rounded-lg p-2 text-gray-400 hover:bg-gray-700 lg:hidden"
            >
              ☰
            </button>
            <div>
              <h2 className="text-sm font-bold text-white">
                {activeTab === 'dashboard' && '📊 Dashboard'}
                {activeTab === 'gateways' && '🔌 Gateway List'}
                {activeTab === 'add' && (editingGw ? '✏️ Edit Gateway' : '➕ New Gateway')}
                {activeTab === 'scripts' && '📜 Scripts & XML'}
                {activeTab === 'help' && '📖 Setup Guide'}
              </h2>
              <p className="text-xs text-gray-500 hidden sm:block">FreeSWITCH Gateway Manager</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={exportData}
              title="Export Gateways"
              className="rounded-lg border border-gray-600 px-3 py-1.5 text-xs font-medium text-gray-300 hover:bg-gray-700 transition"
            >
              📤 Export
            </button>
            <label className="cursor-pointer rounded-lg border border-gray-600 px-3 py-1.5 text-xs font-medium text-gray-300 hover:bg-gray-700 transition">
              📥 Import
              <input type="file" accept=".json" className="hidden" onChange={importData} />
            </label>
            <button
              onClick={() => navTab('add')}
              className="rounded-lg bg-green-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-green-500 transition shadow-lg shadow-green-900/20"
            >
              ➕ Add Gateway
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {/* Toast */}
          {toast && (
            <div className={`fixed right-4 top-4 z-[100] rounded-xl px-5 py-3 text-sm font-medium shadow-xl transition-all ${
              toast.type === 'success' ? 'bg-green-700 text-white' : 'bg-red-700 text-white'
            }`}>
              {toast.msg}
            </div>
          )}

          {/* Import Error */}
          {importError && (
            <div className="mb-4 rounded-xl bg-red-900/40 border border-red-700/40 px-4 py-3 text-sm text-red-300">
              ❌ {importError}
            </div>
          )}

          {/* Dashboard */}
          {activeTab === 'dashboard' && (
            <Dashboard gateways={gateways} onNavigate={(tab) => navTab(tab as Tab)} />
          )}

          {/* Gateway List */}
          {activeTab === 'gateways' && (
            <div className="space-y-5">
              {/* Filters */}
              <div className="flex flex-wrap gap-3">
                <input
                  className="flex-1 min-w-40 rounded-xl border border-gray-600 bg-gray-800 px-4 py-2 text-sm text-gray-200 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="🔍 Gateway name, realm বা username খুঁজুন..."
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                />
                <select
                  className="rounded-xl border border-gray-600 bg-gray-800 px-3 py-2 text-sm text-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
                  value={filterProfile}
                  onChange={e => setFilterProfile(e.target.value)}
                >
                  <option value="all">All Profiles</option>
                  <option value="external">External</option>
                  <option value="internal">Internal</option>
                </select>
                <select
                  className="rounded-xl border border-gray-600 bg-gray-800 px-3 py-2 text-sm text-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
                  value={filterStatus}
                  onChange={e => setFilterStatus(e.target.value)}
                >
                  <option value="all">All Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="unknown">Unknown</option>
                </select>
              </div>

              {/* Results Info */}
              <div className="flex items-center justify-between">
                <p className="text-xs text-gray-500">
                  {filteredGateways.length} টি gateway পাওয়া গেছে {search && `"${search}" এর জন্য`}
                </p>
                {gateways.length > 0 && (
                  <button
                    onClick={() => navTab('scripts')}
                    className="rounded-lg bg-purple-700/50 px-3 py-1.5 text-xs font-medium text-purple-300 hover:bg-purple-700/70 transition"
                  >
                    📜 সব XML Export করুন
                  </button>
                )}
              </div>

              {/* Gateway Cards */}
              {filteredGateways.length > 0 ? (
                <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                  {filteredGateways.map(gw => (
                    <GatewayCard
                      key={gw.id}
                      gateway={gw}
                      onEdit={handleEdit}
                      onDelete={handleDelete}
                      onDuplicate={duplicateGateway}
                      onToggle={toggleStatus}
                      onViewXml={setXmlViewGw}
                    />
                  ))}
                </div>
              ) : (
                <div className="rounded-2xl border border-dashed border-gray-600 bg-gray-800/20 p-16 text-center">
                  <div className="text-5xl mb-4">🔌</div>
                  {gateways.length === 0 ? (
                    <>
                      <h3 className="text-lg font-bold text-gray-300 mb-2">কোনো Gateway নেই</h3>
                      <p className="text-sm text-gray-500 mb-4">প্রথম FreeSWITCH SIP gateway যোগ করুন</p>
                      <button onClick={() => navTab('add')} className="rounded-xl bg-green-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-green-500 transition">
                        ➕ Gateway যোগ করুন
                      </button>
                    </>
                  ) : (
                    <>
                      <h3 className="text-lg font-bold text-gray-300 mb-2">কোনো result নেই</h3>
                      <p className="text-sm text-gray-500">filter পরিবর্তন করুন</p>
                    </>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Add/Edit Form */}
          {activeTab === 'add' && (
            <div className="mx-auto max-w-2xl">
              <div className="mb-5 rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
                <h2 className="text-base font-bold text-white mb-0.5">
                  {editingGw ? `✏️ "${editingGw.name}" Edit করুন` : '➕ নতুন Gateway যোগ করুন'}
                </h2>
                <p className="text-xs text-gray-400">
                  {editingGw ? 'Gateway তথ্য আপডেট করুন' : 'FreeSWITCH SIP gateway configure করুন'}
                </p>
              </div>
              <GatewayForm
                initial={editingGw}
                onSubmit={handleAddOrUpdate}
                onCancel={handleCancel}
              />
            </div>
          )}

          {/* Scripts Page */}
          {activeTab === 'scripts' && (
            <ScriptsPage gateways={gateways} />
          )}

          {/* Help Guide */}
          {activeTab === 'help' && (
            <HelpGuide />
          )}
        </main>
      </div>

      {/* XML Modal */}
      {xmlViewGw && (
        <XmlModal gateway={xmlViewGw} onClose={() => setXmlViewGw(null)} />
      )}
    </div>
  );
}

export interface Gateway {
  id: string;
  name: string;
  username: string;
  password: string;
  realm: string;
  proxy: string;
  registerProxy: string;
  fromUser: string;
  fromDomain: string;
  extension: string;
  expireSeconds: number;
  register: boolean;
  registerTransport: 'udp' | 'tcp' | 'tls';
  retrySeconds: number;
  callerIdInFrom: boolean;
  ping: number;
  context: string;
  sipProfile: 'external' | 'internal';
  cidType: 'none' | 'rpid' | 'pid';
  codec: string;
  status: 'active' | 'inactive' | 'unknown';
  createdAt: string;
  updatedAt: string;
}

export type GatewayFormData = Omit<Gateway, 'id' | 'createdAt' | 'updatedAt'>;

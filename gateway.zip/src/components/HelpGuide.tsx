export default function HelpGuide() {
  const steps = [
    {
      num: '01',
      title: 'FreeSWITCH Install করুন',
      color: 'text-blue-400 border-blue-700/40 bg-blue-900/20',
      commands: [
        'apt update && apt upgrade -y',
        'apt install -y freeswitch freeswitch-config-vanilla',
        'systemctl enable freeswitch && systemctl start freeswitch',
      ],
      note: 'অথবা SignalWire repository থেকে latest version install করুন',
    },
    {
      num: '02',
      title: 'Gateway Manager UI রাখুন VPS-এ',
      color: 'text-green-400 border-green-700/40 bg-green-900/20',
      commands: [
        'cd /var/www/html/',
        '# এই ওয়েবসাইট থেকে script download করুন',
        'chmod +x *.sh',
      ],
      note: 'Scripts & XML section থেকে install_gateways.sh download করুন',
    },
    {
      num: '03',
      title: 'Gateway যোগ করুন',
      color: 'text-purple-400 border-purple-700/40 bg-purple-900/20',
      commands: [
        '# Gateway Manager-এ "Add Gateway" click করুন',
        '# SIP provider দেওয়া info দিন',
        '# Save করুন',
      ],
      note: 'Username, Password, Realm/Domain ঠিকমতো দিন',
    },
    {
      num: '04',
      title: 'XML Config Deploy করুন',
      color: 'text-yellow-400 border-yellow-700/40 bg-yellow-900/20',
      commands: [
        '# "Scripts & XML" > "Install Script" download করুন',
        'sudo bash /var/www/html/install_gateways.sh',
        'fs_cli -x "sofia status gateway"',
      ],
      note: 'Script automatically সব gateway install করে reload করবে',
    },
    {
      num: '05',
      title: 'Status Check করুন',
      color: 'text-cyan-400 border-cyan-700/40 bg-cyan-900/20',
      commands: [
        'fs_cli -x "sofia status"',
        'fs_cli -x "sofia status gateway MY_GW_NAME"',
        'fs_cli -x "sofia profile external rescan"',
      ],
      note: 'REGED দেখালে gateway সফলভাবে registered',
    },
  ];

  const configPaths = [
    { label: 'External Gateways', path: '/etc/freeswitch/sip_profiles/external/', icon: '🌐' },
    { label: 'Internal Gateways', path: '/etc/freeswitch/sip_profiles/internal/', icon: '🏠' },
    { label: 'Dialplan', path: '/etc/freeswitch/dialplan/', icon: '📋' },
    { label: 'Directory', path: '/etc/freeswitch/directory/', icon: '📁' },
    { label: 'Log File', path: '/var/log/freeswitch/freeswitch.log', icon: '📄' },
  ];

  const fsCliCommands = [
    { cmd: 'sofia status', desc: 'সব SIP profile ও gateway দেখুন' },
    { cmd: 'sofia status gateway GW_NAME', desc: 'নির্দিষ্ট gateway status' },
    { cmd: 'sofia profile external rescan', desc: 'External profile reload' },
    { cmd: 'sofia profile internal rescan', desc: 'Internal profile reload' },
    { cmd: 'reloadxml', desc: 'সব XML config reload' },
    { cmd: 'show calls', desc: 'চলমান calls দেখুন' },
    { cmd: 'show channels', desc: 'Active channels' },
    { cmd: 'shutdown', desc: 'FreeSWITCH বন্ধ করুন' },
  ];

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-gradient-to-r from-blue-900/30 to-gray-900/30 border border-blue-700/30 p-5">
        <h2 className="text-lg font-bold text-white mb-1">📖 FreeSWITCH Gateway Setup Guide</h2>
        <p className="text-sm text-gray-400">VPS-এ FreeSWITCH install ও gateway configure করার সম্পূর্ণ গাইড</p>
      </div>

      {/* Steps */}
      <div className="space-y-4">
        {steps.map((step) => (
          <div key={step.num} className={`rounded-2xl border p-5 ${step.color}`}>
            <div className="flex items-start gap-4">
              <div className="shrink-0 text-2xl font-black opacity-50">{step.num}</div>
              <div className="flex-1 min-w-0">
                <h3 className="text-base font-bold text-white mb-3">{step.title}</h3>
                <div className="space-y-1.5 mb-3">
                  {step.commands.map((cmd, i) => (
                    <code key={i} className="block rounded-lg bg-gray-900/60 px-3 py-2 text-xs font-mono text-gray-200 border border-gray-700/30">
                      {cmd.startsWith('#') ? <span className="text-gray-500">{cmd}</span> : cmd}
                    </code>
                  ))}
                </div>
                <p className="text-xs text-gray-400">💡 {step.note}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Config Paths */}
      <div className="rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
        <h3 className="mb-4 text-sm font-semibold text-gray-300">📁 Important Config Paths</h3>
        <div className="space-y-2">
          {configPaths.map((p, i) => (
            <div key={i} className="flex items-center justify-between rounded-xl bg-gray-700/30 px-4 py-2.5">
              <div className="flex items-center gap-2">
                <span>{p.icon}</span>
                <span className="text-sm text-gray-300">{p.label}</span>
              </div>
              <code className="text-xs font-mono text-cyan-400">{p.path}</code>
            </div>
          ))}
        </div>
      </div>

      {/* FS CLI Commands */}
      <div className="rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
        <h3 className="mb-4 text-sm font-semibold text-gray-300">🖥️ Useful fs_cli Commands</h3>
        <div className="space-y-2">
          {fsCliCommands.map((item, i) => (
            <div key={i} className="flex items-center gap-3 rounded-xl bg-gray-700/20 px-4 py-2.5">
              <code className="text-xs font-mono text-green-300 shrink-0 bg-gray-800 rounded px-2 py-1">
                fs_cli -x "{item.cmd}"
              </code>
              <span className="text-xs text-gray-400">{item.desc}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Gateway XML Example */}
      <div className="rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
        <h3 className="mb-3 text-sm font-semibold text-gray-300">📄 Gateway XML উদাহরণ</h3>
        <pre className="rounded-xl bg-gray-950 p-4 text-xs font-mono text-gray-300 leading-relaxed overflow-auto border border-gray-700/50">{`<include>
  <gateway name="my_provider">
    <param name="username" value="1001"/>
    <param name="realm" value="sip.provider.com"/>
    <param name="password" value="secret123"/>
    <param name="proxy" value="sip.provider.com:5060"/>
    <param name="expire-seconds" value="3600"/>
    <param name="register" value="true"/>
    <param name="register-transport" value="udp"/>
    <param name="retry-seconds" value="30"/>
    <param name="ping" value="25"/>
    <param name="context" value="public"/>
  </gateway>
</include>`}</pre>
        <p className="mt-3 text-xs text-gray-500">📌 এই file যাবে: <code className="text-cyan-400">/etc/freeswitch/sip_profiles/external/my_provider.xml</code></p>
      </div>
    </div>
  );
}

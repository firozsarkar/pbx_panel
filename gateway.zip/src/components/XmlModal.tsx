import { useState } from 'react';
import type { Gateway } from '../types/gateway';
import { generateGatewayXML } from '../utils/gatewayXml';

interface Props {
  gateway: Gateway;
  onClose: () => void;
}

export default function XmlModal({ gateway, onClose }: Props) {
  const xml = generateGatewayXML(gateway);
  const filePath = `/etc/freeswitch/sip_profiles/${gateway.sipProfile}/${gateway.name}.xml`;
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(xml).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const downloadXml = () => {
    const blob = new Blob([xml], { type: 'application/xml' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${gateway.name}.xml`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl rounded-2xl border border-gray-700 bg-gray-900 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-700 px-6 py-4">
          <div>
            <h2 className="text-base font-bold text-white">📄 XML Configuration</h2>
            <p className="mt-0.5 text-xs text-gray-400">Gateway: <span className="font-mono text-green-400">{gateway.name}</span></p>
          </div>
          <button onClick={onClose} className="rounded-lg p-2 text-gray-400 hover:bg-gray-700 hover:text-white transition">✕</button>
        </div>

        {/* File Path */}
        <div className="border-b border-gray-700 bg-gray-800/50 px-6 py-3">
          <p className="text-xs text-gray-400 mb-1">📁 VPS-তে রাখুন:</p>
          <code className="block rounded bg-gray-700/60 px-3 py-2 text-xs font-mono text-green-300 break-all">{filePath}</code>
        </div>

        {/* XML Content */}
        <div className="relative p-4">
          <pre className="max-h-[360px] overflow-auto rounded-xl bg-gray-950 p-4 text-xs font-mono text-gray-300 leading-relaxed whitespace-pre-wrap border border-gray-700/50">
            {xml}
          </pre>
        </div>

        {/* Commands */}
        <div className="border-t border-gray-700 bg-gray-800/30 px-6 py-4">
          <p className="mb-2 text-xs font-medium text-gray-400">🖥️ VPS Terminal Commands:</p>
          <div className="space-y-1.5">
            {[
              `nano ${filePath}`,
              `fs_cli -x "sofia profile ${gateway.sipProfile} rescan"`,
              `fs_cli -x "sofia status gateway ${gateway.name}"`,
            ].map((cmd, i) => (
              <code key={i} className="block rounded bg-gray-900 px-3 py-1.5 text-xs font-mono text-cyan-300 border border-gray-700/50">{cmd}</code>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 border-t border-gray-700 px-6 py-4">
          <button
            onClick={copyToClipboard}
            className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition ${
              copied ? 'bg-green-600 text-white' : 'bg-blue-600 text-white hover:bg-blue-500'
            }`}
          >
            {copied ? '✅ Copied!' : '📋 Copy XML'}
          </button>
          <button
            onClick={downloadXml}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-green-600 py-2.5 text-sm font-semibold text-white hover:bg-green-500 transition"
          >
            ⬇️ Download .xml
          </button>
        </div>
      </div>
    </div>
  );
}

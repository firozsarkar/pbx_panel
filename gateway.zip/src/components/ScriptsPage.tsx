import { useState } from 'react';
import type { Gateway } from '../types/gateway';
import { generateGatewayXML, generateAllGatewaysXML, generateInstallScript, generateAPIScript } from '../utils/gatewayXml';
import ScriptModal from './ScriptModal';

interface Props {
  gateways: Gateway[];
}

export default function ScriptsPage({ gateways }: Props) {
  const [showScriptModal, setShowScriptModal] = useState(false);

  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  const downloadFile = (content: string, filename: string, type = 'text/plain') => {
    const blob = new Blob([content], { type });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const allXml = generateAllGatewaysXML(gateways);
  const installScript = generateInstallScript(gateways);
  const apiScript = generateAPIScript();

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-gradient-to-r from-purple-900/30 to-gray-900/30 border border-purple-700/30 p-5">
        <h2 className="text-lg font-bold text-white mb-1">📜 Scripts & XML Export</h2>
        <p className="text-sm text-gray-400">Gateway config generate করুন এবং VPS-এ deploy করুন</p>
      </div>

      {/* All Gateways XML */}
      <div className="rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-gray-300">📦 All Gateways XML ({gateways.length} টি)</h3>
          <div className="flex gap-2">
            <button
              onClick={() => copyText(allXml, 'all-xml')}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${copiedId === 'all-xml' ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
            >
              {copiedId === 'all-xml' ? '✅ Copied' : '📋 Copy'}
            </button>
            <button
              onClick={() => downloadFile(allXml, 'all_gateways.xml', 'application/xml')}
              className="rounded-lg bg-blue-600/80 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 transition"
            >
              ⬇️ Download XML
            </button>
          </div>
        </div>
        <pre className="max-h-48 overflow-auto rounded-xl bg-gray-950 p-4 text-xs font-mono text-gray-300 border border-gray-700/50 whitespace-pre-wrap">
          {allXml}
        </pre>
      </div>

      {/* Install Script */}
      <div className="rounded-2xl border border-green-700/40 bg-green-900/10 p-5">
        <div className="mb-2 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-green-300">🚀 Auto Install Script</h3>
            <p className="text-xs text-gray-500 mt-0.5">সব gateway এক command-এ VPS-এ install করুন</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => copyText(installScript, 'install-script')}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${copiedId === 'install-script' ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
            >
              {copiedId === 'install-script' ? '✅ Copied' : '📋 Copy'}
            </button>
            <button
              onClick={() => downloadFile(installScript, 'install_gateways.sh')}
              className="rounded-lg bg-green-600/80 px-3 py-1.5 text-xs font-medium text-white hover:bg-green-500 transition"
            >
              ⬇️ Download .sh
            </button>
          </div>
        </div>
        <div className="mb-3 rounded-lg bg-gray-900/60 border border-green-700/20 px-4 py-2.5 text-xs">
          <p className="text-gray-400 mb-1">📌 VPS-এ রাখুন ও রান করুন:</p>
          <code className="block text-green-300 font-mono">sudo bash /var/www/html/install_gateways.sh</code>
        </div>
        <pre className="max-h-48 overflow-auto rounded-xl bg-gray-950 p-4 text-xs font-mono text-gray-300 border border-gray-700/50 whitespace-pre">
          {installScript.slice(0, 800)}...
        </pre>
      </div>

      {/* API Script */}
      <div className="rounded-2xl border border-blue-700/40 bg-blue-900/10 p-5">
        <div className="mb-2 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-blue-300">🔌 API Helper Script</h3>
            <p className="text-xs text-gray-500 mt-0.5">Gateway status check ও management করুন</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => copyText(apiScript, 'api-script')}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${copiedId === 'api-script' ? 'bg-green-600 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
            >
              {copiedId === 'api-script' ? '✅ Copied' : '📋 Copy'}
            </button>
            <button
              onClick={() => downloadFile(apiScript, 'fs-api.sh')}
              className="rounded-lg bg-blue-600/80 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500 transition"
            >
              ⬇️ Download .sh
            </button>
          </div>
        </div>
        <div className="mb-3 rounded-lg bg-gray-900/60 border border-blue-700/20 px-4 py-2.5 text-xs space-y-1">
          {['bash /var/www/html/fs-api.sh list', 'bash /var/www/html/fs-api.sh status my_gw', 'bash /var/www/html/fs-api.sh reload external'].map((cmd, i) => (
            <code key={i} className="block text-cyan-300 font-mono">{cmd}</code>
          ))}
        </div>
      </div>

      {/* Per-Gateway XML */}
      {gateways.length > 0 && (
        <div className="rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
          <h3 className="mb-4 text-sm font-semibold text-gray-300">📄 Individual Gateway XML</h3>
          <div className="space-y-3">
            {gateways.map(gw => (
              <div key={gw.id} className="flex items-center justify-between rounded-xl bg-gray-700/30 px-4 py-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`h-2 w-2 rounded-full shrink-0 ${
                      gw.status === 'active' ? 'bg-green-400' : gw.status === 'inactive' ? 'bg-red-400' : 'bg-yellow-400'
                    }`} />
                    <span className="text-sm font-medium text-gray-200">{gw.name}</span>
                  </div>
                  <code className="block text-xs text-gray-500 mt-0.5 font-mono truncate">
                    /etc/freeswitch/sip_profiles/{gw.sipProfile}/{gw.name}.xml
                  </code>
                </div>
                <div className="flex shrink-0 gap-2 ml-3">
                  <button
                    onClick={() => copyText(generateGatewayXML(gw), `gw-${gw.id}`)}
                    className={`rounded-lg px-2.5 py-1.5 text-xs font-medium transition ${copiedId === `gw-${gw.id}` ? 'bg-green-600 text-white' : 'bg-gray-600 text-gray-300 hover:bg-gray-500'}`}
                  >
                    {copiedId === `gw-${gw.id}` ? '✅' : '📋'}
                  </button>
                  <button
                    onClick={() => downloadFile(generateGatewayXML(gw), `${gw.name}.xml`, 'application/xml')}
                    className="rounded-lg bg-blue-700/50 px-2.5 py-1.5 text-xs font-medium text-blue-300 hover:bg-blue-600/50 transition"
                  >
                    ⬇️
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showScriptModal && (
        <ScriptModal gateways={gateways} onClose={() => setShowScriptModal(false)} />
      )}
    </div>
  );
}

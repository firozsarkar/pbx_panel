import { useState } from 'react';
import type { Gateway } from '../types/gateway';
import { generateInstallScript, generateAPIScript } from '../utils/gatewayXml';

interface Props {
  gateways: Gateway[];
  onClose: () => void;
}

type Tab = 'install' | 'api';

export default function ScriptModal({ gateways, onClose }: Props) {
  const [tab, setTab] = useState<Tab>('install');
  const [copied, setCopied] = useState(false);

  const script = tab === 'install' ? generateInstallScript(gateways) : generateAPIScript();
  const filename = tab === 'install' ? 'install_gateways.sh' : 'fs-api.sh';

  const copyToClipboard = () => {
    navigator.clipboard.writeText(script).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const downloadScript = () => {
    const blob = new Blob([script], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="w-full max-w-3xl rounded-2xl border border-gray-700 bg-gray-900 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-700 px-6 py-4">
          <div>
            <h2 className="text-base font-bold text-white">🖥️ Shell Scripts</h2>
            <p className="mt-0.5 text-xs text-gray-400">VPS-এ রান করুন: <code className="text-cyan-400">bash /var/www/html/{filename}</code></p>
          </div>
          <button onClick={onClose} className="rounded-lg p-2 text-gray-400 hover:bg-gray-700 hover:text-white transition">✕</button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-700">
          <button
            onClick={() => setTab('install')}
            className={`flex-1 py-3 text-sm font-medium transition ${tab === 'install' ? 'bg-green-900/30 text-green-400 border-b-2 border-green-500' : 'text-gray-400 hover:text-gray-200'}`}
          >
            📦 Install Script ({gateways.length} gateways)
          </button>
          <button
            onClick={() => setTab('api')}
            className={`flex-1 py-3 text-sm font-medium transition ${tab === 'api' ? 'bg-blue-900/30 text-blue-400 border-b-2 border-blue-500' : 'text-gray-400 hover:text-gray-200'}`}
          >
            🔌 API Helper Script
          </button>
        </div>

        {/* Info Box */}
        <div className="border-b border-gray-700 bg-gray-800/40 px-6 py-3">
          {tab === 'install' ? (
            <div className="text-xs text-gray-400 space-y-1">
              <p>📌 <strong className="text-gray-200">VPS-এ রাখুন:</strong> <code className="text-yellow-300">/var/www/html/install_gateways.sh</code></p>
              <p>🚀 <strong className="text-gray-200">রান করুন:</strong> <code className="text-green-300">sudo bash /var/www/html/install_gateways.sh</code></p>
              <p>⚡ এই script সব gateway XML file তৈরি করবে এবং FreeSWITCH reload করবে</p>
            </div>
          ) : (
            <div className="text-xs text-gray-400 space-y-1">
              <p>📌 <strong className="text-gray-200">VPS-এ রাখুন:</strong> <code className="text-yellow-300">/var/www/html/fs-api.sh</code></p>
              <p>🚀 <strong className="text-gray-200">Gateway status:</strong> <code className="text-green-300">bash /var/www/html/fs-api.sh status my_gateway</code></p>
              <p>📋 <strong className="text-gray-200">সব list:</strong> <code className="text-green-300">bash /var/www/html/fs-api.sh list</code></p>
            </div>
          )}
        </div>

        {/* Script Content */}
        <div className="p-4">
          <pre className="max-h-[380px] overflow-auto rounded-xl bg-gray-950 p-4 text-xs font-mono text-gray-300 leading-relaxed whitespace-pre border border-gray-700/50">
            {script}
          </pre>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 border-t border-gray-700 px-6 py-4">
          <button
            onClick={copyToClipboard}
            className={`flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition ${
              copied ? 'bg-green-600 text-white' : 'bg-blue-600 text-white hover:bg-blue-500'
            }`}
          >
            {copied ? '✅ Copied!' : '📋 Copy Script'}
          </button>
          <button
            onClick={downloadScript}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-green-600 py-2.5 text-sm font-semibold text-white hover:bg-green-500 transition"
          >
            ⬇️ Download {filename}
          </button>
        </div>
      </div>
    </div>
  );
}

interface Props {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  gatewayCount: number;
  activeCount: number;
}

export default function Sidebar({ activeTab, setActiveTab, gatewayCount, activeCount }: Props) {
  const navItems = [
    { id: 'dashboard', icon: '📊', label: 'Dashboard' },
    { id: 'gateways', icon: '🔌', label: 'Gateways' },
    { id: 'add', icon: '➕', label: 'Add Gateway' },
    { id: 'scripts', icon: '📜', label: 'Scripts & XML' },
    { id: 'help', icon: '📖', label: 'Setup Guide' },
  ];

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col bg-gray-900 border-r border-gray-700/60">
      {/* Logo */}
      <div className="flex items-center gap-3 border-b border-gray-700/60 px-5 py-5">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-green-500 to-emerald-700 text-xl shadow-lg shadow-green-900/30">
          📞
        </div>
        <div>
          <h1 className="text-sm font-bold text-white leading-tight">FreeSWITCH</h1>
          <p className="text-xs text-green-400 font-medium">Gateway Manager</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-2 border-b border-gray-700/60 p-3">
        <div className="rounded-lg bg-gray-800 p-2.5 text-center">
          <div className="text-xl font-bold text-white">{gatewayCount}</div>
          <div className="text-xs text-gray-400">Total</div>
        </div>
        <div className="rounded-lg bg-green-900/40 border border-green-800/40 p-2.5 text-center">
          <div className="text-xl font-bold text-green-400">{activeCount}</div>
          <div className="text-xs text-green-500">Active</div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 space-y-1 p-3">
        {navItems.map(item => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex w-full items-center gap-3 rounded-xl px-4 py-2.5 text-sm font-medium transition ${
              activeTab === item.id
                ? 'bg-green-600/20 text-green-400 border border-green-600/30'
                : 'text-gray-400 hover:bg-gray-700/50 hover:text-gray-200'
            }`}
          >
            <span className="text-base">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-gray-700/60 p-4">
        <div className="rounded-xl bg-gray-800/60 p-3 text-center">
          <p className="text-xs text-gray-500">VPS Path</p>
          <code className="block text-xs font-mono text-cyan-400 mt-1 break-all">/var/www/html/</code>
        </div>
      </div>
    </aside>
  );
}

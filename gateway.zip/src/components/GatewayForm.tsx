import React, { useState, useEffect } from 'react';
import type { Gateway, GatewayFormData } from '../types/gateway';

interface Props {
  initial?: Gateway | null;
  onSubmit: (data: GatewayFormData) => void;
  onCancel: () => void;
}

const defaultForm: GatewayFormData = {
  name: '',
  username: '',
  password: '',
  realm: '',
  proxy: '',
  registerProxy: '',
  fromUser: '',
  fromDomain: '',
  extension: '',
  expireSeconds: 3600,
  register: true,
  registerTransport: 'udp',
  retrySeconds: 30,
  callerIdInFrom: false,
  ping: 25,
  context: 'public',
  sipProfile: 'external',
  cidType: 'none',
  codec: '',
  status: 'active',
};

export default function GatewayForm({ initial, onSubmit, onCancel }: Props) {
  const [form, setForm] = useState<GatewayFormData>(
    initial ? { ...defaultForm, ...initial } : defaultForm
  );
  const [errors, setErrors] = useState<Partial<Record<keyof GatewayFormData, string>>>({});
  const [showAdvanced, setShowAdvanced] = useState(false);

  useEffect(() => {
    if (initial) setForm({ ...defaultForm, ...initial });
    else setForm(defaultForm);
  }, [initial]);

  const validate = (): boolean => {
    const e: Partial<Record<keyof GatewayFormData, string>> = {};
    if (!form.name.trim()) e.name = 'Gateway name আবশ্যক';
    if (!/^[a-zA-Z0-9_-]+$/.test(form.name)) e.name = 'শুধু letter, number, _ এবং - ব্যবহার করুন';
    if (!form.username.trim()) e.username = 'Username আবশ্যক';
    if (!form.password.trim()) e.password = 'Password আবশ্যক';
    if (!form.realm.trim()) e.realm = 'Realm/Domain আবশ্যক';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) onSubmit(form);
  };

  const set = (key: keyof GatewayFormData, value: unknown) =>
    setForm(f => ({ ...f, [key]: value }));

  const inputCls = (key: keyof GatewayFormData) =>
    `w-full px-3 py-2 rounded-lg border text-sm bg-gray-900 text-gray-100 focus:outline-none focus:ring-2 focus:ring-green-500 transition ${
      errors[key] ? 'border-red-500' : 'border-gray-600'
    }`;

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Basic Info */}
      <div className="rounded-xl border border-gray-700 bg-gray-800/50 p-5">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-green-400 uppercase tracking-wider">
          <span className="text-lg">🔌</span> Basic Configuration
        </h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Gateway Name *</label>
            <input
              className={inputCls('name')}
              value={form.name}
              onChange={e => set('name', e.target.value.replace(/\s/g, '_'))}
              placeholder="my_gateway"
            />
            {errors.name && <p className="mt-1 text-xs text-red-400">{errors.name}</p>}
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">SIP Profile</label>
            <select className={inputCls('sipProfile')} value={form.sipProfile} onChange={e => set('sipProfile', e.target.value)}>
              <option value="external">External</option>
              <option value="internal">Internal</option>
            </select>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Username *</label>
            <input className={inputCls('username')} value={form.username} onChange={e => set('username', e.target.value)} placeholder="1001" />
            {errors.username && <p className="mt-1 text-xs text-red-400">{errors.username}</p>}
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Password *</label>
            <input className={inputCls('password')} type="password" value={form.password} onChange={e => set('password', e.target.value)} placeholder="••••••••" />
            {errors.password && <p className="mt-1 text-xs text-red-400">{errors.password}</p>}
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Realm / Domain *</label>
            <input className={inputCls('realm')} value={form.realm} onChange={e => set('realm', e.target.value)} placeholder="sip.provider.com" />
            {errors.realm && <p className="mt-1 text-xs text-red-400">{errors.realm}</p>}
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Proxy</label>
            <input className={inputCls('proxy')} value={form.proxy} onChange={e => set('proxy', e.target.value)} placeholder="sip.provider.com:5060" />
          </div>
        </div>
      </div>

      {/* Registration */}
      <div className="rounded-xl border border-gray-700 bg-gray-800/50 p-5">
        <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-blue-400 uppercase tracking-wider">
          <span className="text-lg">📡</span> Registration Settings
        </h3>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="flex items-center gap-3">
            <label className="relative inline-flex cursor-pointer items-center">
              <input type="checkbox" className="sr-only peer" checked={form.register} onChange={e => set('register', e.target.checked)} />
              <div className="h-6 w-11 rounded-full bg-gray-600 peer-checked:bg-green-500 transition-colors after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all peer-checked:after:translate-x-5"></div>
            </label>
            <span className="text-sm text-gray-300">Register with Provider</span>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Transport</label>
            <select className={inputCls('registerTransport')} value={form.registerTransport} onChange={e => set('registerTransport', e.target.value)}>
              <option value="udp">UDP</option>
              <option value="tcp">TCP</option>
              <option value="tls">TLS</option>
            </select>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Expire Seconds</label>
            <input className={inputCls('expireSeconds')} type="number" value={form.expireSeconds} onChange={e => set('expireSeconds', parseInt(e.target.value))} />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Retry Seconds</label>
            <input className={inputCls('retrySeconds')} type="number" value={form.retrySeconds} onChange={e => set('retrySeconds', parseInt(e.target.value))} />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Ping Interval (sec)</label>
            <input className={inputCls('ping')} type="number" value={form.ping} onChange={e => set('ping', parseInt(e.target.value))} />
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium text-gray-400">Inbound Context</label>
            <input className={inputCls('context')} value={form.context} onChange={e => set('context', e.target.value)} placeholder="public" />
          </div>
        </div>
      </div>

      {/* Advanced Toggle */}
      <button
        type="button"
        onClick={() => setShowAdvanced(v => !v)}
        className="flex w-full items-center justify-between rounded-xl border border-gray-700 bg-gray-800/30 px-5 py-3 text-sm text-gray-400 hover:text-gray-200 transition"
      >
        <span className="flex items-center gap-2">⚙️ Advanced Settings</span>
        <span>{showAdvanced ? '▲' : '▼'}</span>
      </button>

      {showAdvanced && (
        <div className="rounded-xl border border-gray-700 bg-gray-800/50 p-5">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">From User</label>
              <input className={inputCls('fromUser')} value={form.fromUser} onChange={e => set('fromUser', e.target.value)} placeholder="same as username" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">From Domain</label>
              <input className={inputCls('fromDomain')} value={form.fromDomain} onChange={e => set('fromDomain', e.target.value)} placeholder="same as realm" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">Extension</label>
              <input className={inputCls('extension')} value={form.extension} onChange={e => set('extension', e.target.value)} placeholder="same as username" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">Register Proxy</label>
              <input className={inputCls('registerProxy')} value={form.registerProxy} onChange={e => set('registerProxy', e.target.value)} placeholder="same as proxy" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">CID Type</label>
              <select className={inputCls('cidType')} value={form.cidType} onChange={e => set('cidType', e.target.value)}>
                <option value="none">None</option>
                <option value="rpid">RPID</option>
                <option value="pid">PID</option>
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">Codec</label>
              <input className={inputCls('codec')} value={form.codec} onChange={e => set('codec', e.target.value)} placeholder="PCMU,PCMA,G729" />
            </div>
            <div className="flex items-center gap-3">
              <label className="relative inline-flex cursor-pointer items-center">
                <input type="checkbox" className="sr-only peer" checked={form.callerIdInFrom} onChange={e => set('callerIdInFrom', e.target.checked)} />
                <div className="h-6 w-11 rounded-full bg-gray-600 peer-checked:bg-blue-500 transition-colors after:absolute after:left-[2px] after:top-[2px] after:h-5 after:w-5 after:rounded-full after:bg-white after:transition-all peer-checked:after:translate-x-5"></div>
              </label>
              <span className="text-sm text-gray-300">Caller ID in From Header</span>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-gray-400">Initial Status</label>
              <select className={inputCls('status')} value={form.status} onChange={e => set('status', e.target.value as Gateway['status'])}>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
                <option value="unknown">Unknown</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Buttons */}
      <div className="flex gap-3">
        <button
          type="submit"
          className="flex-1 rounded-xl bg-green-600 px-6 py-3 text-sm font-semibold text-white hover:bg-green-500 transition shadow-lg shadow-green-900/30"
        >
          {initial ? '💾 Update Gateway' : '➕ Add Gateway'}
        </button>
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 rounded-xl border border-gray-600 px-6 py-3 text-sm font-semibold text-gray-300 hover:bg-gray-700 transition"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}

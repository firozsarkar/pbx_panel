import type { Gateway } from '../types/gateway';

interface Props {
  gateways: Gateway[];
  onNavigate: (tab: string) => void;
}

export default function Dashboard({ gateways, onNavigate }: Props) {
  const active = gateways.filter(g => g.status === 'active').length;
  const inactive = gateways.filter(g => g.status === 'inactive').length;
  const unknown = gateways.filter(g => g.status === 'unknown').length;
  const external = gateways.filter(g => g.sipProfile === 'external').length;
  const internal = gateways.filter(g => g.sipProfile === 'internal').length;
  const registering = gateways.filter(g => g.register).length;

  const statCards = [
    { label: 'মোট Gateways', value: gateways.length, color: 'from-blue-600 to-blue-800', icon: '🔌', bg: 'bg-blue-900/20 border-blue-700/40' },
    { label: 'Active (REGED)', value: active, color: 'from-green-600 to-green-800', icon: '✅', bg: 'bg-green-900/20 border-green-700/40' },
    { label: 'Inactive', value: inactive, color: 'from-red-600 to-red-800', icon: '❌', bg: 'bg-red-900/20 border-red-700/40' },
    { label: 'Unknown', value: unknown, color: 'from-yellow-600 to-yellow-800', icon: '⚠️', bg: 'bg-yellow-900/20 border-yellow-700/40' },
    { label: 'External Profile', value: external, color: 'from-purple-600 to-purple-800', icon: '🌐', bg: 'bg-purple-900/20 border-purple-700/40' },
    { label: 'Internal Profile', value: internal, color: 'from-cyan-600 to-cyan-800', icon: '🏠', bg: 'bg-cyan-900/20 border-cyan-700/40' },
  ];

  const recentGateways = [...gateways].sort(
    (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
  ).slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-green-900/50 via-emerald-900/30 to-gray-900/50 border border-green-700/30 p-6">
        <div className="flex items-center gap-4">
          <div className="text-5xl">📞</div>
          <div>
            <h2 className="text-xl font-bold text-white">FreeSWITCH Gateway Manager</h2>
            <p className="text-sm text-gray-400 mt-1">
              আপনার সব SIP gateway ওয়েব থেকে manage করুন। XML config generate করুন এবং VPS-এ deploy করুন।
            </p>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {statCards.map((card, i) => (
          <div key={i} className={`rounded-2xl border p-5 ${card.bg}`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-400 mb-1">{card.label}</p>
                <p className="text-3xl font-bold text-white">{card.value}</p>
              </div>
              <span className="text-3xl">{card.icon}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="mb-3 text-sm font-semibold text-gray-400 uppercase tracking-wider">⚡ Quick Actions</h3>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <button
            onClick={() => onNavigate('add')}
            className="flex flex-col items-center gap-2 rounded-xl border border-green-700/40 bg-green-900/20 p-4 text-sm font-medium text-green-400 hover:bg-green-900/40 transition"
          >
            <span className="text-2xl">➕</span>
            New Gateway
          </button>
          <button
            onClick={() => onNavigate('gateways')}
            className="flex flex-col items-center gap-2 rounded-xl border border-blue-700/40 bg-blue-900/20 p-4 text-sm font-medium text-blue-400 hover:bg-blue-900/40 transition"
          >
            <span className="text-2xl">🔌</span>
            View All
          </button>
          <button
            onClick={() => onNavigate('scripts')}
            className="flex flex-col items-center gap-2 rounded-xl border border-purple-700/40 bg-purple-900/20 p-4 text-sm font-medium text-purple-400 hover:bg-purple-900/40 transition"
          >
            <span className="text-2xl">📜</span>
            Scripts
          </button>
          <button
            onClick={() => onNavigate('help')}
            className="flex flex-col items-center gap-2 rounded-xl border border-yellow-700/40 bg-yellow-900/20 p-4 text-sm font-medium text-yellow-400 hover:bg-yellow-900/40 transition"
          >
            <span className="text-2xl">📖</span>
            Setup Guide
          </button>
        </div>
      </div>

      {/* Register Stats */}
      <div className="rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
        <h3 className="mb-4 text-sm font-semibold text-gray-300">📊 Registration Overview</h3>
        <div className="space-y-3">
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-gray-400">Registering</span>
              <span className="text-green-400">{registering}/{gateways.length}</span>
            </div>
            <div className="h-2 rounded-full bg-gray-700">
              <div
                className="h-2 rounded-full bg-gradient-to-r from-green-500 to-emerald-400 transition-all"
                style={{ width: gateways.length ? `${(registering / gateways.length) * 100}%` : '0%' }}
              />
            </div>
          </div>
          <div>
            <div className="mb-1 flex justify-between text-xs">
              <span className="text-gray-400">Active (REGED)</span>
              <span className="text-blue-400">{active}/{gateways.length}</span>
            </div>
            <div className="h-2 rounded-full bg-gray-700">
              <div
                className="h-2 rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all"
                style={{ width: gateways.length ? `${(active / gateways.length) * 100}%` : '0%' }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Recent Gateways */}
      {recentGateways.length > 0 && (
        <div className="rounded-2xl border border-gray-700 bg-gray-800/40 p-5">
          <h3 className="mb-4 text-sm font-semibold text-gray-300">🕐 Recent Gateways</h3>
          <div className="space-y-2">
            {recentGateways.map(gw => (
              <div key={gw.id} className="flex items-center justify-between rounded-xl bg-gray-700/30 px-4 py-2.5">
                <div className="flex items-center gap-3">
                  <span className={`h-2 w-2 rounded-full ${
                    gw.status === 'active' ? 'bg-green-400' : gw.status === 'inactive' ? 'bg-red-400' : 'bg-yellow-400'
                  } animate-pulse`} />
                  <span className="text-sm font-medium text-gray-200">{gw.name}</span>
                  <span className="text-xs text-gray-500">{gw.realm}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-gray-500 bg-gray-700 rounded px-2 py-0.5">{gw.sipProfile}</span>
                  <span className="text-xs text-gray-500 uppercase font-mono">{gw.registerTransport}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {gateways.length === 0 && (
        <div className="rounded-2xl border border-dashed border-gray-600 bg-gray-800/20 p-10 text-center">
          <div className="text-5xl mb-4">🚀</div>
          <h3 className="text-lg font-bold text-gray-300 mb-2">কোনো Gateway নেই</h3>
          <p className="text-sm text-gray-500 mb-4">প্রথম FreeSWITCH gateway যোগ করুন</p>
          <button
            onClick={() => onNavigate('add')}
            className="rounded-xl bg-green-600 px-6 py-2.5 text-sm font-semibold text-white hover:bg-green-500 transition"
          >
            ➕ প্রথম Gateway যোগ করুন
          </button>
        </div>
      )}
    </div>
  );
}

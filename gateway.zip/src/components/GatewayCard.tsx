import type { Gateway } from '../types/gateway';

interface Props {
  gateway: Gateway;
  onEdit: (gw: Gateway) => void;
  onDelete: (id: string) => void;
  onDuplicate: (id: string) => void;
  onToggle: (id: string) => void;
  onViewXml: (gw: Gateway) => void;
}

const statusColors: Record<Gateway['status'], string> = {
  active: 'bg-green-500',
  inactive: 'bg-red-500',
  unknown: 'bg-yellow-500',
};

const statusLabels: Record<Gateway['status'], string> = {
  active: 'REGED',
  inactive: 'UNREGED',
  unknown: 'UNKNOWN',
};

export default function GatewayCard({ gateway: gw, onEdit, onDelete, onDuplicate, onToggle, onViewXml }: Props) {
  return (
    <div className={`group relative rounded-2xl border bg-gray-800/60 backdrop-blur transition hover:border-gray-500 ${
      gw.status === 'active' ? 'border-green-700/50' : gw.status === 'inactive' ? 'border-red-700/50' : 'border-gray-700'
    }`}>
      {/* Status Bar */}
      <div className={`absolute left-0 top-0 h-full w-1 rounded-l-2xl ${statusColors[gw.status]}`} />

      <div className="p-5 pl-6">
        {/* Header */}
        <div className="mb-3 flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-lg">🔌</span>
              <h3 className="truncate text-base font-bold text-white">{gw.name}</h3>
            </div>
            <p className="mt-0.5 truncate text-xs text-gray-400">{gw.realm}</p>
          </div>
          <div className="flex shrink-0 flex-col items-end gap-1">
            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold ${
              gw.status === 'active' ? 'bg-green-900/60 text-green-300' :
              gw.status === 'inactive' ? 'bg-red-900/60 text-red-300' :
              'bg-yellow-900/60 text-yellow-300'
            }`}>
              <span className={`h-1.5 w-1.5 rounded-full ${statusColors[gw.status]} animate-pulse`}></span>
              {statusLabels[gw.status]}
            </span>
            <span className="text-xs text-gray-500 bg-gray-700/50 rounded px-2 py-0.5">{gw.sipProfile}</span>
          </div>
        </div>

        {/* Info Grid */}
        <div className="mb-4 grid grid-cols-2 gap-x-4 gap-y-1.5 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-gray-500">👤</span>
            <span className="text-gray-400">User:</span>
            <span className="font-mono text-gray-200 truncate">{gw.username}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-gray-500">🌐</span>
            <span className="text-gray-400">Proxy:</span>
            <span className="font-mono text-gray-200 truncate">{gw.proxy || gw.realm}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-gray-500">🚌</span>
            <span className="text-gray-400">Transport:</span>
            <span className="font-mono text-gray-200 uppercase">{gw.registerTransport}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-gray-500">⏱️</span>
            <span className="text-gray-400">Expire:</span>
            <span className="font-mono text-gray-200">{gw.expireSeconds}s</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-gray-500">📥</span>
            <span className="text-gray-400">Context:</span>
            <span className="font-mono text-gray-200 truncate">{gw.context}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-gray-500">📡</span>
            <span className="text-gray-400">Register:</span>
            <span className={`font-semibold ${gw.register ? 'text-green-400' : 'text-red-400'}`}>{gw.register ? 'Yes' : 'No'}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-2 border-t border-gray-700/50 pt-3">
          <button
            onClick={() => onViewXml(gw)}
            className="flex items-center gap-1 rounded-lg bg-blue-900/40 px-3 py-1.5 text-xs font-medium text-blue-300 hover:bg-blue-800/60 transition"
          >
            📄 XML
          </button>
          <button
            onClick={() => onEdit(gw)}
            className="flex items-center gap-1 rounded-lg bg-yellow-900/40 px-3 py-1.5 text-xs font-medium text-yellow-300 hover:bg-yellow-800/60 transition"
          >
            ✏️ Edit
          </button>
          <button
            onClick={() => onDuplicate(gw.id)}
            className="flex items-center gap-1 rounded-lg bg-purple-900/40 px-3 py-1.5 text-xs font-medium text-purple-300 hover:bg-purple-800/60 transition"
          >
            📋 Copy
          </button>
          <button
            onClick={() => onToggle(gw.id)}
            className={`flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
              gw.status === 'active'
                ? 'bg-red-900/40 text-red-300 hover:bg-red-800/60'
                : 'bg-green-900/40 text-green-300 hover:bg-green-800/60'
            }`}
          >
            {gw.status === 'active' ? '⏹️ Disable' : '▶️ Enable'}
          </button>
          <button
            onClick={() => { if (confirm(`"${gw.name}" গেটওয়ে ডিলিট করবেন?`)) onDelete(gw.id); }}
            className="flex items-center gap-1 rounded-lg bg-gray-700/50 px-3 py-1.5 text-xs font-medium text-gray-400 hover:bg-red-900/40 hover:text-red-300 transition ml-auto"
          >
            🗑️ Delete
          </button>
        </div>
      </div>
    </div>
  );
}
